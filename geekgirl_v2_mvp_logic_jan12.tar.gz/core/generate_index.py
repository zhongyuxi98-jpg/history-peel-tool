import os
from mission_data import CIVIL_RIGHTS_MISSIONS

def generate_index():
    links = "".join([f'<li><a href="{mid}_workspace.html" target="_blank">{mid}: {data["question"]}</a></li>' 
                    for mid, data in CIVIL_RIGHTS_MISSIONS.items()])
    
    html = f"""
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <title>Mission Control</title>
        <style>
            body {{ font-family: 'Segoe UI', sans-serif; padding: 50px; background: #f0f2f5; color: #1d3557; }}
            .menu {{ max-width: 800px; margin: auto; background: white; padding: 40px; border-radius: 16px; box-shadow: 0 10px 25px rgba(0,0,0,0.05); }}
            h1 {{ border-bottom: 2px solid #e63946; padding-bottom: 10px; }}
            ul {{ list-style: none; padding: 0; margin-top: 30px; }}
            li {{ margin-bottom: 15px; background: #f8f9fa; border-radius: 8px; transition: 0.2s; }}
            li:hover {{ transform: translateX(10px); background: #eef2f7; }}
            a {{ text-decoration: none; color: #457b9d; font-weight: bold; display: block; padding: 15px; }}
        </style>
    </head>
    <body>
        <div class="menu">
            <h1>🚀 Civil Rights Workspace</h1>
            <p>Select a mission to begin your PEEL construction:</p>
            <ul>{links}</ul>
        </div>
    </body>
    </html>
    """
    os.makedirs("assets/missions", exist_ok=True)
    with open("assets/missions/index.html", "w", encoding="utf-8") as f:
        f.write(html)
    print("✅ Index page created: assets/missions/index.html")

if __name__ == "__main__":
    generate_index()
