GeekGirl Visual Spec v1.0-alpha

Module: Civil Rights

Base Unit:
- 60x30mm (L0–L3)
- 45x18mm (MECHANISM)

Line Types:
- L0: Double solid
- L1: Dashed
- L2: Dotted
- L3: Thick solid
- MECH: Thin solid

Color Axis:
- P1 Warm Red → P7 Blue Gray (Discrete)

Classification:
- Topic-based badge system

Status:
- Baseline locked
- Physical print validated
