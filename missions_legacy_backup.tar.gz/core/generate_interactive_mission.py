import os

HTML_TEMPLATE = """<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>PEEL Workspace - {mid}</title>
    <style>
        body {{ font-family: 'Segoe UI', sans-serif; background: #f4f7f6; margin: 0; color: #333; }}
        .main-wrapper {{
            display: flex;
            height: 100vh;
            overflow: hidden;
        }}
        .main {{ 
            flex: 1; 
            flex-grow: 1;
            padding: 40px; 
            overflow-y: auto;
            transition: margin-right 0.3s ease;
        }}

        /* 可折叠侧边栏 */
        .sidebar-toggle {{
            position: fixed;
            right: 0;
            top: 50%;
            transform: translateY(-50%);
            width: 50px;
            height: 50px;
            background: #1d3557;
            color: white;
            border: none;
            border-radius: 12px 0 0 12px;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            z-index: 1000;
            box-shadow: -2px 0 8px rgba(0,0,0,0.15);
            transition: all 0.3s ease;
        }}
        .sidebar-toggle:hover {{
            background: #457b9d;
            width: 55px;
        }}
        .sidebar-toggle.collapsed {{
            right: 0;
        }}
        .sidebar-toggle.expanded {{
            right: 380px;
        }}
        
        /* 右侧双窗口：上方知识区可滚动；下方 explainer-window 固定 */
        .sidebar {{
            width: 380px;
            height: 100vh;
            background: #fff;
            border-left: 1px solid #dee2e6;
            padding: 25px;
            box-shadow: -5px 0 15px rgba(0, 0, 0, 0.1);
            display: flex;
            flex-direction: column;
            gap: 14px;
            box-sizing: border-box;
            overflow-y: auto;
            margin-right: -380px;
            transition: margin-right 0.3s ease;
        }}
        .sidebar.expanded {{
            margin-right: 0;
        }}
        .sidebar-content {{
            flex: 1;
            overflow-y: auto;
            padding-right: 6px; /* 给滚动条留空间 */
        }}
        
        /* 侧边栏遮罩层 */
        .sidebar-overlay {{
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.3);
            z-index: 998;
            display: none;
            opacity: 0;
            transition: opacity 0.3s ease;
        }}
        .sidebar-overlay.visible {{
            display: block;
            opacity: 1;
        }}
        .header {{ border-bottom: 3px solid #1d3557; margin-bottom: 25px; padding-bottom: 15px; }}
        .q-text {{ font-size: 20px; font-weight: 700; color: #1d3557; }}
        .nav-bar {{ margin-bottom: 25px; display: flex; gap: 10px; }}
        
        button {{ border: none; border-radius: 6px; cursor: pointer; font-weight: 600; transition: 0.2s; }}
        .btn-save {{ background: #2a9d8f; color: white; padding: 10px 18px; }}
        .btn-export {{ background: #f4a261; color: white; padding: 10px 18px; }}
        
        /* 💡 显式按钮样式 */
        .tag-row {{ display: flex; align-items: center; gap: 5px; margin-bottom: 8px; }}
        .tag {{ flex: 1; padding: 8px; border-radius: 4px; font-size: 12px; cursor: pointer; border: 1px solid #ddd; background: #fff; border-left: 4px solid #457b9d; text-align: left; }}
        .tag:hover {{ background: #f8f9fa; }}
        .explain-btn {{ background: #457b9d; color: white; padding: 8px; font-size: 12px; border-radius: 4px; width: 35px; }}
        
        .editor-box {{ margin-bottom: 15px; position: relative; }}
        .label {{ color: #e63946; font-size: 11px; font-weight: 800; text-transform: uppercase; margin-bottom: 5px; }}
        textarea {{ 
            width: 100%; 
            height: 95px; 
            border: none; 
            border-radius: 8px; 
            padding: 12px; 
            font-size: 14px; 
            resize: none; 
            line-height: 1.5; 
            box-sizing: border-box;
            background: #fafafa;
            box-shadow: 0 1px 3px rgba(0,0,0,0.08);
            transition: box-shadow 0.2s;
        }}
        textarea:focus {{
            outline: none;
            background: #fff;
            box-shadow: 0 2px 8px rgba(0,0,0,0.12);
        }}
        
        /* 字数统计 */
        .word-count {{
            position: absolute;
            bottom: 8px;
            right: 12px;
            font-size: 11px;
            color: #6c757d;
            background: rgba(255,255,255,0.9);
            padding: 2px 6px;
            border-radius: 4px;
            pointer-events: none;
        }}
        
        /* 全局字数统计气泡 */
        .global-word-count {{
            position: fixed;
            bottom: 30px;
            right: 30px;
            background: #1d3557;
            color: white;
            padding: 12px 20px;
            border-radius: 24px;
            font-size: 14px;
            font-weight: 600;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            z-index: 100;
            pointer-events: none;
        }}
        
        /* [Agent-02 守门员] 提交校验提示动画 */
        @keyframes shake {{
            0%, 100% {{ transform: translateX(0); }}
            25% {{ transform: translateX(-5px); }}
            75% {{ transform: translateX(5px); }}
        }}
        
        /* Focus 按钮 */
        .focus-btn {{
            background: none;
            border: none;
            color: #667eea;
            font-size: 16px;
            cursor: pointer;
            padding: 4px 8px;
            border-radius: 4px;
            transition: background 0.2s;
        }}
        .focus-btn:hover {{
            background: #f0f0f0;
        }}
        
        /* Focus Modal */
        .focus-modal {{
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            z-index: 10000;
            display: none;
            align-items: center;
            justify-content: center;
            opacity: 0;
            transition: opacity 0.3s ease;
        }}
        .focus-modal.visible {{
            display: flex;
            opacity: 1;
        }}
        .focus-modal-content {{
            background: #fff;
            border-radius: 12px;
            padding: 30px;
            width: 90%;
            max-width: 900px;
            max-height: 85vh;
            display: flex;
            flex-direction: column;
            box-shadow: 0 10px 40px rgba(0,0,0,0.3);
        }}
        .focus-modal-header {{
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 2px solid #e1e4e8;
        }}
        .focus-modal-title {{
            font-size: 18px;
            font-weight: 700;
            color: #1d3557;
        }}
        .focus-modal-close {{
            background: #6c757d;
            color: white;
            border: none;
            padding: 8px 16px;
            border-radius: 6px;
            cursor: pointer;
            font-weight: 600;
            font-size: 14px;
        }}
        .focus-modal-close:hover {{
            background: #5a6268;
        }}
        .focus-textarea {{
            width: 100%;
            flex: 1;
            min-height: 400px;
            border: none;
            border-radius: 8px;
            padding: 20px;
            font-size: 16px;
            line-height: 1.8;
            resize: none;
            background: #fafafa;
            box-shadow: 0 1px 3px rgba(0,0,0,0.08);
            font-family: inherit;
            box-sizing: border-box;
        }}
        .focus-textarea:focus {{
            outline: none;
            background: #fff;
            box-shadow: 0 2px 8px rgba(0,0,0,0.12);
        }}
        .focus-modal-footer {{
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 15px;
            padding-top: 15px;
            border-top: 2px solid #e1e4e8;
        }}
        .focus-word-count {{
            font-size: 13px;
            color: #6c757d;
            font-weight: 600;
        }}
        .focus-save-btn {{
            background: #667eea;
            color: white;
            border: none;
            padding: 10px 24px;
            border-radius: 6px;
            cursor: pointer;
            font-weight: 600;
            font-size: 14px;
        }}
        .focus-save-btn:hover {{
            background: #5568d3;
        }}

        /* Essay constructor layout */
        #module-toolbar {{ display:flex; flex-wrap:wrap; gap:8px; margin: 8px 0 16px 0; }}
        .toolbar-btn {{ padding:8px 12px; border-radius:999px; border:none; background:#1d3557; color:#fff; font-size:13px; cursor:pointer; }}
        .toolbar-btn.secondary {{ background:#6c757d; }}
        .toolbar-btn:hover {{ opacity:0.9; transform:translateY(-1px); }}

        #essay-constructor {{ display:flex; flex-direction:column; gap:14px; }}
        .essay-module {{ 
            border: none; 
            border-radius:10px; 
            padding:12px 14px; 
            background:#fff; 
            max-width: 1000px; 
            width: 100%;
            box-shadow: 0 2px 6px rgba(0,0,0,0.08);
        }}
        .main {{ max-width: 1000px; width: 90%; }}
        .module-header {{ display:flex; justify-content:space-between; align-items:center; margin-bottom:8px; gap:8px; }}
        .module-controls-left {{ display:flex; align-items:center; gap:6px; flex-wrap:wrap; }}
        .module-controls-right {{ display:flex; align-items:center; gap:6px; }}
        .module-tag {{ font-size:12px; font-weight:700; text-transform:uppercase; color:#1d3557; }}
        .move-btn {{ border:1px solid #ced4da; background:#f8f9fa; border-radius:4px; padding:2px 6px; font-size:11px; cursor:pointer; }}
        .move-btn:hover {{ background:#e9ecef; }}
        .mode-toggle {{ border:none; background:#f1faee; color:#1d3557; border-radius:999px; padding:4px 10px; font-size:11px; cursor:pointer; }}
        .mode-toggle:hover {{ background:#e0fbfc; }}
        .module-delete {{ border:none; background:#fff; color:#e63946; cursor:pointer; font-size:14px; }}
        .module-delete:hover {{ color:#b02a37; }}

        .free-hint {{ font-size:11px; color:#6c757d; margin-top:4px; line-height:1.4; }}

        #export-preview {{ display:none; margin-top:24px; border:1px solid #dee2e6; border-radius:10px; padding:16px; background:#fff; }}
        #export-essay {{ line-height:1.7; font-size:14px; }}
        
        /* 👨‍🏫 右侧讲解老师窗口 */
        #explainer-window {{
            position: sticky;
            bottom: 0;
            background: #1d3557; /* 蓝色窗口 */
            border-radius: 12px;
            padding: 14px 14px 12px 14px;
            border: 1px solid rgba(255,255,255,0.18);
            box-shadow: 0 10px 30px rgba(29,53,87,0.25);
        }}
        #explain-box {{ font-size: 13px; line-height: 1.6; color: #f1faee; min-height: 110px; white-space: pre-wrap; }}

        /* Toast 提示样式 */
        #toast-container {{
            position: fixed;
            top: 20px;
            left: 50%;
            transform: translateX(-50%);
            z-index: 10000;
            pointer-events: none;
        }}
        .toast {{
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 16px 24px;
            border-radius: 12px;
            box-shadow: 0 8px 24px rgba(0,0,0,0.3);
            font-weight: 600;
            font-size: 15px;
            display: flex;
            align-items: center;
            gap: 12px;
            animation: toastSlideIn 0.3s ease-out, toastFadeOut 0.3s ease-in 2.7s forwards;
            max-width: 600px;
        }}
        @keyframes toastSlideIn {{
            from {{ opacity: 0; transform: translateY(-20px); }}
            to {{ opacity: 1; transform: translateY(0); }}
        }}
        @keyframes toastFadeOut {{
            to {{ opacity: 0; transform: translateY(-20px); }}
        }}
        .toast-icon {{
            font-size: 20px;
        }}

        /* 🚀 底部 AI Review 样式 */
        .review-actions {{ display: flex; gap: 12px; margin: 30px 0; }}
        .ai-review-trigger {{ background: #e63946; color: white; flex: 1; padding: 20px; font-size: 18px; box-shadow: 0 4px 15px rgba(230,57,70,0.3); }}
        .preview-btn {{ background: #457b9d; color: white; flex: 1; padding: 20px; font-size: 18px; box-shadow: 0 4px 15px rgba(69,123,157,0.3); }}
        
        /* Preview Modal */
        #preview-modal {{ display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.7); z-index: 1000; overflow-y: auto; }}
        #preview-modal .modal-content {{ background: #fff; margin: 40px auto; max-width: 1000px; width: 90%; border-radius: 12px; padding: 30px; box-shadow: 0 10px 40px rgba(0,0,0,0.3); position: relative; }}
        .modal-header {{ font-size: 24px; font-weight: 700; color: #1d3557; margin-bottom: 20px; }}
        .modal-body {{ max-height: 60vh; overflow-y: auto; padding: 20px; background: #f8f9fa; border-radius: 8px; line-height: 1.8; white-space: pre-wrap; }}
        .modal-body p {{ margin: 0 0 16px 0; }}
        .modal-body p:last-child {{ margin-bottom: 0; }}
        .modal-footer {{ display: flex; gap: 12px; margin-top: 20px; justify-content: flex-end; }}
        .modal-btn {{ padding: 12px 24px; border-radius: 6px; border: none; cursor: pointer; font-weight: 600; }}
        .modal-btn-secondary {{ background: #6c757d; color: white; }}
        .modal-btn-primary {{ background: #e63946; color: white; }}
        
        /* 批改视图：左右双栏布局（同屏对照修改） */
        #feedback-view {{ display: none; margin-top: 30px; }}
        .feedback-container {{ display: flex; gap: 20px; min-height: 500px; }}
        .feedback-left {{
            flex: 1;
            background: #f8f9fa;
            border-radius: 12px;
            padding: 20px;
            overflow-y: auto;
            max-height: 80vh;
        }}
        .feedback-right {{
            flex: 1;
            background: #fff;
            border: 2px solid #e63946;
            border-radius: 12px;
            padding: 20px;
            overflow-y: auto;
            max-height: 80vh;
        }}
        .feedback-left h3 {{ color: #1d3557; margin-bottom: 15px; display: flex; align-items: center; gap: 10px; }}
        .feedback-right h3 {{ color: #e63946; margin-bottom: 15px; }}
        .view-mode-toggle {{
            background: #457b9d;
            color: white;
            border: none;
            padding: 6px 12px;
            border-radius: 6px;
            font-size: 12px;
            cursor: pointer;
            font-weight: 600;
        }}
        .view-mode-toggle:hover {{ opacity: 0.9; }}
        
        /* 呼吸灯高亮效果 */
        @keyframes breathe {{
            0%, 100% {{ box-shadow: 0 0 0 rgba(102, 126, 234, 0); }}
            50% {{ box-shadow: 0 0 20px rgba(102, 126, 234, 0.8); }}
        }}
        .essay-module.highlight {{
            animation: breathe 2s ease-in-out infinite;
            border: 2px solid #667eea !important;
        }}
        
        /* AI Review 联动高亮动画 */
        @keyframes activeGlow {{
            0% {{
                background-color: transparent;
                box-shadow: inset 0 0 0 rgba(224, 187, 228, 0);
            }}
            16.66% {{
                background-color: rgba(224, 187, 228, 0.3);
                box-shadow: inset 0 0 20px rgba(224, 187, 228, 0.5);
            }}
            33.33% {{
                background-color: transparent;
                box-shadow: inset 0 0 0 rgba(224, 187, 228, 0);
            }}
            50% {{
                background-color: rgba(224, 187, 228, 0.3);
                box-shadow: inset 0 0 20px rgba(224, 187, 228, 0.5);
            }}
            66.66% {{
                background-color: transparent;
                box-shadow: inset 0 0 0 rgba(224, 187, 228, 0);
            }}
            83.33% {{
                background-color: rgba(224, 187, 228, 0.3);
                box-shadow: inset 0 0 20px rgba(224, 187, 228, 0.5);
            }}
            100% {{
                background-color: transparent;
                box-shadow: inset 0 0 0 rgba(224, 187, 228, 0);
            }}
        }}
        .essay-module.active-glow {{
            animation: activeGlow 2s ease-in-out;
        }}
        
        /* AI 反馈卡片样式 */
        .ai-feedback-card {{
            background: #fff;
            border-left: 4px solid #e63946;
            padding: 15px;
            margin-bottom: 15px;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }}
        .locate-btn {{
            background: #667eea;
            color: white;
            border: none;
            padding: 6px 12px;
            border-radius: 6px;
            font-size: 12px;
            cursor: pointer;
            font-weight: 600;
            margin-top: 8px;
        }}
        .locate-btn:hover {{ opacity: 0.9; }}
        
        #ai-review-result {{ border: 2px solid #e63946; border-radius: 12px; background: white; margin-bottom: 40px; overflow: hidden; }}
        
        /* 模式标签样式 */
        .mode-badge {{
            display: inline-block;
            padding: 4px 12px;
            border-radius: 12px;
            font-size: 11px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin-left: 12px;
        }}
        .mode-badge.audit {{
            background: #fff3cd;
            color: #856404;
        }}
        .mode-badge.practice {{
            background: #d1ecf1;
            color: #0c5460;
        }}
        
        /* Mission Lab 抽屉样式 */
        #mission-lab-drawer .mission-card {{
            background: white;
            border-radius: 16px;
            padding: 24px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.05), 0 1px 3px rgba(0,0,0,0.1);
            transition: transform 0.2s, box-shadow 0.2s;
            cursor: pointer;
            border: 2px solid #e1e4e8;
            display: flex;
            flex-direction: column;
            min-height: 200px;
        }}
        #mission-lab-drawer .mission-card:hover {{
            transform: translateY(-5px);
            box-shadow: 0 12px 20px rgba(0,0,0,0.1);
            border-color: #667eea;
        }}
        #mission-lab-drawer .mid-tag {{
            background: #e1f5fe;
            color: #0288d1;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: 600;
            align-self: flex-start;
            margin-bottom: 15px;
        }}
        #mission-lab-drawer .mission-card h3 {{
            margin: 10px 0;
            color: #2c3e50;
            font-size: 1.4rem;
        }}
        #mission-lab-drawer .question-box {{
            background: #f8f9fa;
            border-left: 4px solid #667eea;
            padding: 12px;
            margin-top: auto;
            border-radius: 4px;
        }}
        #mission-lab-drawer .question-box p {{
            margin: 0;
            font-style: italic;
            color: #5f6368;
            font-size: 0.95rem;
        }}
        
        /* 计时器样式 */
        .timer-container {{
            position: relative;
        }}
        .timer-btn {{
            background: #1d3557;
            color: white;
            border: none;
            padding: 10px 18px;
            border-radius: 6px;
            cursor: pointer;
            font-weight: 600;
            font-size: 14px;
            transition: background 0.2s;
        }}
        .timer-btn:hover {{
            background: #457b9d;
        }}
        .timer-panel {{
            position: absolute;
            top: 100%;
            right: 0;
            margin-top: 8px;
            background: white;
            border-radius: 8px;
            padding: 16px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            min-width: 280px;
            z-index: 1000;
            display: none;
        }}
        .timer-panel.visible {{
            display: block;
        }}
        .timer-display {{
            font-size: 32px;
            font-weight: 700;
            text-align: center;
            margin: 16px 0;
            font-family: 'Courier New', monospace;
            color: #1d3557;
            transition: color 0.3s;
        }}
        .timer-display.warning {{
            color: #e63946;
            animation: timerBlink 1s ease-in-out infinite;
        }}
        @keyframes timerBlink {{
            0%, 100% {{ opacity: 1; }}
            50% {{ opacity: 0.5; }}
        }}
        .timer-controls {{
            display: flex;
            gap: 8px;
            margin-bottom: 12px;
        }}
        .timer-control-btn {{
            flex: 1;
            padding: 8px 12px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-weight: 600;
            font-size: 13px;
            transition: opacity 0.2s;
        }}
        .timer-control-btn:hover {{
            opacity: 0.9;
        }}
        .timer-start-btn {{
            background: #2a9d8f;
            color: white;
        }}
        .timer-pause-btn {{
            background: #f4a261;
            color: white;
        }}
        .timer-reset-btn {{
            background: #6c757d;
            color: white;
        }}
        .timer-mode-select {{
            display: flex;
            gap: 8px;
            margin-bottom: 12px;
        }}
        .timer-mode-btn {{
            flex: 1;
            padding: 6px 10px;
            border: 1px solid #dee2e6;
            border-radius: 6px;
            background: #f8f9fa;
            cursor: pointer;
            font-size: 12px;
            font-weight: 600;
            transition: all 0.2s;
        }}
        .timer-mode-btn.active {{
            background: #667eea;
            color: white;
            border-color: #667eea;
        }}
        .timer-countdown-input {{
            width: 100%;
            padding: 8px;
            border: 1px solid #dee2e6;
            border-radius: 6px;
            font-size: 14px;
            margin-top: 8px;
            box-sizing: border-box;
        }}
        .timer-countdown-label {{
            font-size: 12px;
            color: #6c757d;
            margin-top: 8px;
        }}
        
        /* 隐藏 Knowledge Hub 侧边栏 */
        .sidebar,
        #knowledge-sidebar {{
            display: none !important;
        }}
        
        /* 隐藏侧边栏切换按钮 */
        .sidebar-toggle {{
            display: none !important;
        }}
        
        /* 隐藏侧边栏遮罩层 */
        .sidebar-overlay {{
            display: none !important;
        }}
        
        /* 隐藏 Mission Lab 按钮 */
        .btn-mission-lab {{
            display: none !important;
        }}
        
        /* 确保 Writing Area 填满整个宽度 */
        .main {{
            width: 100% !important;
            margin-right: 0 !important;
        }}
        
        /* Visual Audit V2.0 双栏对比视图样式 - 手术级视觉诊断 */
        #review-overlay {{
            display: none; /* 默认隐藏，通过 JavaScript 控制显示 */
            margin-top: 30px;
            width: 100%;
            visibility: visible !important; /* 确保可见性不被覆盖 */
            height: auto !important; /* 确保高度自适应 */
            min-height: 500px !important; /* 确保有显示空间 */
            opacity: 1 !important; /* 确保不透明 */
            z-index: 1000 !important; /* 防止被遮挡 */
            position: relative; /* 确保 z-index 生效 */
        }}
        /* 确保 review-overlay 显示时所有子元素也可见 */
        #review-overlay[style*="display: block"] {{
            display: block !important;
            visibility: visible !important;
            height: auto !important;
            opacity: 1 !important;
        }}
        /* 确保所有评审相关的容器默认可见（当父容器显示时） */
        #review-overlay #overall-grade,
        #review-overlay #overall-score-text,
        #review-overlay #overall-summary,
        #review-overlay #criteria-grid,
        #review-overlay #action-list,
        #review-overlay #paragraph-cards,
        #review-overlay #model-essay-content,
        #review-overlay #review-container,
        #review-overlay #review-overall-score,
        #review-overlay #review-dimension-scores,
        #review-overlay #review-diagnostics {{
            visibility: visible !important;
            height: auto !important;
            opacity: 1 !important;
        }}
        .review-overlay-container {{
            display: flex;
            gap: 24px;
            min-height: 600px;
            max-height: 85vh;
        }}
        .review-left-panel {{
            flex: 0 0 60%;
            background: #f8f9fa;
            border-radius: 12px;
            padding: 24px;
            overflow-y: auto;
            box-shadow: 0 4px 12px rgba(30, 41, 59, 0.1);
            border: 1px solid #e2e8f0;
        }}
        .review-right-panel {{
            flex: 0 0 40%;
            background: #fff;
            border: 2px solid #1e293b;
            border-radius: 12px;
            padding: 24px;
            overflow-y: auto;
            box-shadow: 0 4px 12px rgba(30, 41, 59, 0.15);
        }}
        .review-panel-title {{
            color: #1e293b;
            margin-bottom: 20px;
            font-size: 20px;
            font-weight: 800;
            border-bottom: 3px solid #1e293b;
            padding-bottom: 12px;
        }}
        .review-text-content {{
            line-height: 1.8;
            font-size: 15px;
            color: #334155;
        }}
        .review-text-content mark {{
            background: #fef3c7;
            padding: 2px 6px;
            border-radius: 4px;
            cursor: pointer;
            transition: all 0.3s;
            border-bottom: 2px solid #f59e0b;
            text-decoration: none;
        }}
        .review-text-content mark:hover {{
            background: #fde68a;
            box-shadow: 0 2px 6px rgba(245, 158, 11, 0.4);
        }}
        .review-text-content mark.active {{
            background: #fbbf24;
            box-shadow: 0 0 12px rgba(245, 158, 11, 0.6);
            transform: scale(1.02);
            animation: highlightPulse 1.5s ease-in-out, breatheGlow 2s ease-in-out infinite;
        }}
        @keyframes highlightPulse {{
            0%, 100% {{ box-shadow: 0 0 12px rgba(245, 158, 11, 0.6); }}
            50% {{ box-shadow: 0 0 20px rgba(245, 158, 11, 0.9); }}
        }}
        /* 呼吸灯高亮效果 */
        @keyframes breatheGlow {{
            0%, 100% {{
                box-shadow: 0 0 12px rgba(245, 158, 11, 0.6);
                opacity: 1;
            }}
            50% {{
                box-shadow: 0 0 24px rgba(245, 158, 11, 0.9), 0 0 40px rgba(245, 158, 11, 0.5);
                opacity: 0.95;
            }}
        }}
        .review-text-content .error-mark {{
            background: #fee2e2;
            border-bottom: 2px dashed #dc2626;
            text-decoration: wavy underline;
            text-decoration-color: #dc2626;
        }}
        .review-scores-header {{
            margin-bottom: 24px;
            padding-bottom: 20px;
            border-bottom: 3px solid #1e293b;
        }}
        .overall-score {{
            text-align: center;
            margin-bottom: 24px;
        }}
        .score-label {{
            font-size: 13px;
            color: #64748b;
            margin-bottom: 8px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }}
        .score-value {{
            font-size: 56px;
            font-weight: 800;
            color: #1e293b;
            line-height: 1;
        }}
        .dimension-scores {{
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 16px;
        }}
        .dimension-score-item {{
            background: #f1f5f9;
            padding: 16px;
            border-radius: 10px;
            border: 1px solid #e2e8f0;
            transition: all 0.2s;
        }}
        .dimension-score-item:hover {{
            background: #e2e8f0;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(30, 41, 59, 0.1);
        }}
        .dimension-score-label {{
            font-size: 12px;
            color: #64748b;
            margin-bottom: 12px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }}
        /* 隐藏数字显示，只保留进度条作为主要视觉 */
        .dimension-score-value {{
            display: none; /* 禁止直接显示数字 */
        }}
        /* 进度条样式 - 作为主要视觉元素 */
        .dimension-progress-bar {{
            width: 100%;
            height: 12px;
            background: #e2e8f0;
            border-radius: 6px;
            overflow: hidden;
            position: relative;
            box-shadow: inset 0 2px 4px rgba(0,0,0,0.1);
        }}
        .dimension-progress-fill {{
            height: 100%;
            background: linear-gradient(90deg, #1e293b 0%, #475569 100%);
            border-radius: 6px;
            transition: width 0.8s ease-out;
            position: relative;
        }}
        /* 进度条上的百分比标签（可选，作为辅助信息） */
        .dimension-progress-label {{
            position: absolute;
            right: 8px;
            top: 50%;
            transform: translateY(-50%);
            font-size: 10px;
            font-weight: 700;
            color: #1e293b;
            z-index: 1;
        }}
        
        /* Visual Audit V3.1 结构化卡片系统样式 */
        #review-container {{
            display: flex;
            flex-direction: column;
            gap: 24px;
        }}
        
        /* 通用卡片样式 */
        .card {{
            background: white;
            border-radius: 16px;
            padding: 24px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.05);
            border: 1px solid #E2E8F0;
            transition: transform 0.2s;
        }}
        .card:hover {{
            transform: translateY(-2px);
        }}
        .card-title {{
            font-size: 20px;
            font-weight: 800;
            color: #1e293b;
            margin: 0 0 20px 0;
        }}
        
        /* [总分卡片] Score Card - Hero Section */
        #score-card {{
            text-align: center;
            background: linear-gradient(135deg, #1e293b 0%, #4F46E5 100%);
            color: white;
            padding: 48px 32px;
        }}
        .score-circle {{
            width: 120px;
            height: 120px;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.2);
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 24px;
            font-size: 48px;
            font-weight: 800;
        }}
        .score-grade {{
            font-size: 32px;
            font-weight: 800;
            margin-bottom: 12px;
        }}
        .score-summary {{
            font-size: 16px;
            line-height: 1.6;
            opacity: 0.95;
            max-width: 600px;
            margin: 0 auto;
        }}
        
        /* [评分维度卡片] Criteria Card - 2x2 Grid */
        .criteria-grid {{
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 16px;
        }}
        .criterion-item {{
            background: #f8fafc;
            border-radius: 8px;
            padding: 16px;
            border: 1px solid #e2e8f0;
        }}
        .criterion-label {{
            font-size: 14px;
            font-weight: 700;
            color: #1e293b;
            text-transform: uppercase;
            margin-bottom: 12px;
        }}
        .criterion-progress-bar {{
            width: 100%;
            height: 10px;
            background: #e2e8f0;
            border-radius: 5px;
            overflow: hidden;
        }}
        .criterion-progress-fill {{
            height: 100%;
            background: linear-gradient(90deg, #4F46E5 0%, #1e293b 100%);
            border-radius: 5px;
            transition: width 0.8s ease-out;
        }}
        
        /* [修改任务卡片] Actions Card - Checklist */
        .action-list {{
            display: flex;
            flex-direction: column;
            gap: 12px;
        }}
        .action-item {{
            display: flex;
            align-items: flex-start;
            gap: 12px;
            padding: 12px;
            background: #f8fafc;
            border-radius: 8px;
        }}
        .action-checkbox {{
            width: 20px;
            height: 20px;
            margin-top: 2px;
            cursor: pointer;
            accent-color: #4F46E5;
        }}
        .action-text {{
            flex: 1;
            font-size: 14px;
            line-height: 1.6;
            color: #1e293b;
            transition: all 0.3s;
        }}
        .action-item.completed .action-text {{
            text-decoration: line-through;
            opacity: 0.5;
        }}
        
        /* [段落诊断区域] Paragraphs Area */
        .paragraph-card {{
            background: #f8fafc;
            border: 1px solid #e2e8f0;
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 16px;
        }}
        .paragraph-header {{
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 16px;
        }}
        .paragraph-type {{
            font-size: 14px;
            font-weight: 700;
            color: #4F46E5;
            text-transform: uppercase;
            padding: 6px 12px;
            background: #eef2ff;
            border-radius: 6px;
        }}
        .peel-status {{
            display: flex;
            gap: 8px;
            align-items: center;
        }}
        .status-dot {{
            height: 8px;
            width: 8px;
            border-radius: 50%;
            display: inline-block;
            margin-right: 4px;
        }}
        .dot-pass {{
            background: #48BB78;
        }}
        .dot-fail {{
            background: #F56565;
        }}
        .paragraph-surgery {{
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 16px;
            margin-top: 16px;
        }}
        .diagnosis-box {{
            background: #FFF5F5;
            border-left: 4px solid #F56565;
            padding: 16px;
            border-radius: 8px;
        }}
        .diagnosis-label {{
            font-size: 12px;
            font-weight: 700;
            color: #F56565;
            text-transform: uppercase;
            margin-bottom: 12px;
        }}
        .issue-list {{
            display: flex;
            flex-direction: column;
            gap: 8px;
        }}
        .issue-item {{
            font-size: 13px;
            line-height: 1.6;
            color: #1e293b;
        }}
        .revision-box {{
            background: #F0FFF4;
            border-left: 4px solid #48BB78;
            padding: 16px;
            border-radius: 8px;
        }}
        .revision-label {{
            font-size: 12px;
            font-weight: 700;
            color: #48BB78;
            text-transform: uppercase;
            margin-bottom: 12px;
        }}
        .revision-text {{
            font-size: 13px;
            line-height: 1.6;
            color: #1e293b;
            white-space: pre-wrap;
        }}
        
        /* [范文卡片] Model Essay Card */
        .model-essay-toggle {{
            width: 100%;
            padding: 16px;
            background: linear-gradient(135deg, #4F46E5 0%, #1e293b 100%);
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.3s;
        }}
        .model-essay-toggle:hover {{
            transform: translateY(-2px);
            box-shadow: 0 6px 16px rgba(79, 70, 229, 0.3);
        }}
        .model-essay-content {{
            margin-top: 20px;
            padding: 20px;
            background: #f8fafc;
            border-radius: 8px;
            line-height: 1.8;
            font-size: 14px;
            color: #1e293b;
            white-space: pre-wrap;
            display: none;
        }}
        .model-essay-content.show {{
            display: block;
        }}
        
        /* 移动端适配 */
        @media (max-width: 768px) {{
            #review-container {{
                padding: 0 0.5rem;
            }}
            .criteria-grid {{
                grid-template-columns: 1fr;
            }}
            .paragraph-surgery {{
                grid-template-columns: 1fr;
            }}
        }}
        
        .review-diagnostics {{
            display: flex;
            flex-direction: column;
            gap: 20px;
        }}
        .diagnostic-card {{
            background: #f8fafc;
            border: 1px solid #cbd5e1;
            border-radius: 12px;
            padding: 20px;
            box-shadow: 0 2px 6px rgba(30, 41, 59, 0.08);
            transition: all 0.3s;
        }}
        .diagnostic-card:hover {{
            box-shadow: 0 6px 16px rgba(30, 41, 59, 0.12);
            transform: translateY(-2px);
            border-color: #94a3b8;
        }}
        .diagnostic-card.active {{
            border-color: #1e293b;
            box-shadow: 0 0 16px rgba(30, 41, 59, 0.2);
            background: #fff;
        }}
        .diagnostic-text {{
            font-size: 14px;
            line-height: 1.6;
            color: #1e293b;
            margin-bottom: 16px;
            font-weight: 500;
        }}
        .comparison-box {{
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 16px;
            margin-top: 16px;
        }}
        .comparison-before {{
            background: #fef2f2;
            border-left: 4px solid #dc2626;
            padding: 14px;
            border-radius: 8px;
        }}
        .comparison-after {{
            background: #f0fdf4;
            border-left: 4px solid #16a34a;
            padding: 14px;
            border-radius: 8px;
        }}
        .comparison-label {{
            font-size: 11px;
            font-weight: 800;
            text-transform: uppercase;
            margin-bottom: 10px;
            letter-spacing: 0.5px;
        }}
        .comparison-before .comparison-label {{
            color: #dc2626;
        }}
        .comparison-after .comparison-label {{
            color: #16a34a;
        }}
        .comparison-text {{
            font-size: 13px;
            line-height: 1.6;
            color: #1e293b;
            font-weight: 500;
        }}
        /* 段落高亮闪烁动画 */
        .essay-module.highlight-flash {{
            animation: flashHighlight 2s ease-in-out;
            border: 3px solid #1e293b !important;
            box-shadow: 0 0 20px rgba(30, 41, 59, 0.4) !important;
        }}
        @keyframes flashHighlight {{
            0%, 100% {{
                background-color: transparent;
                box-shadow: 0 0 20px rgba(30, 41, 59, 0.4);
            }}
            25%, 75% {{
                background-color: rgba(30, 41, 59, 0.1);
                box-shadow: 0 0 30px rgba(30, 41, 59, 0.6);
            }}
            50% {{
                background-color: rgba(30, 41, 59, 0.15);
                box-shadow: 0 0 40px rgba(30, 41, 59, 0.8);
            }}
        }}
    </style>
</head>

<body>
    <div class="main-wrapper">
    <div class="main">
        <div class="nav-bar">
            <button class="btn-workspace" onclick="backToWorkspace()" style="background: #6c757d; color: white; padding: 10px 18px; border-radius: 6px; border: none; cursor: pointer; font-weight: 600;">← Workspace</button>
            <button class="btn-save" onclick="save()">💾 SAVE</button>
            <button class="btn-mission-lab" onclick="showMissionLab()" style="background: #764ba2; color: white; padding: 10px 18px; border-radius: 6px; border: none; cursor: pointer; font-weight: 600;">📚 Mission Lab</button>
            <select id="language-setting" style="padding: 10px; border-radius: 6px; border: 1.5px solid #007bff;">
                <option value="dual" selected>🌓 Dual-Language</option>
                <option value="en">🇬🇧 English Only</option>
                <option value="zh">🇨🇳 Chinese Only</option>
            </select>
            <select id="exam-type-selector" style="padding: 10px; border-radius: 6px; border: 1.5px solid #28a745;">
                <option value="AL_ECON" selected>📚 A-Level Economics</option>
                <option value="IELTS">📝 IELTS Academic</option>
            </select>
            <div class="timer-container">
                <button class="timer-btn" onclick="toggleTimerPanel()">⏱️ Timer</button>
                <div class="timer-panel" id="timer-panel">
                    <div class="timer-display" id="timer-display">00:00:00</div>
                    <div class="timer-controls">
                        <button class="timer-control-btn timer-start-btn" id="timer-start-btn" onclick="startTimer()">Start</button>
                        <button class="timer-control-btn timer-pause-btn" id="timer-pause-btn" onclick="pauseTimer()" style="display: none;">Pause</button>
                        <button class="timer-control-btn timer-reset-btn" onclick="resetTimer()">Reset</button>
                    </div>
                    <div class="timer-mode-select">
                        <button class="timer-mode-btn active" id="timer-mode-up" onclick="setTimerMode('up')">Count Up</button>
                        <button class="timer-mode-btn" id="timer-mode-down" onclick="setTimerMode('down')">Count Down</button>
                    </div>
                    <div id="timer-countdown-input-container" style="display: none;">
                        <label class="timer-countdown-label">Set countdown (minutes):</label>
                        <input type="number" class="timer-countdown-input" id="timer-countdown-input" value="45" min="1" max="180" placeholder="45">
                    </div>
                </div>
            </div>
            <button class="btn-export" onclick="exportDoc()">📥 EXPORT + FEEDBACK</button>
        </div>

        <!-- Mission Lab 抽屉 -->
        <div id="mission-lab-drawer" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.7); z-index: 2000; overflow-y: auto;">
            <div style="background: #fff; margin: 40px auto; max-width: 1000px; border-radius: 12px; padding: 30px; box-shadow: 0 10px 40px rgba(0,0,0,0.3);">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px;">
                    <h2 style="font-size: 28px; color: #1d3557;">📚 Mission Lab</h2>
                    <button onclick="closeMissionLab()" style="background: #6c757d; color: white; border: none; padding: 10px 20px; border-radius: 6px; cursor: pointer; font-weight: 600;">✕ Close</button>
                </div>
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 25px;">
                    <div class="mission-card" onclick="location.href='assets/missions/CR_M1_workspace.html'">
                        <span class="mid-tag">Mission CR_M1</span>
                        <h3>Opposition in the 1950s</h3>
                        <div class="question-box"><p>"Assess the reasons for the opposition to the Civil Rights movement in the Southern states in the 1950s."</p></div>
                    </div>
                    <div class="mission-card" onclick="location.href='assets/missions/CR_M2_workspace.html'">
                        <span class="mid-tag">Mission CR_M2</span>
                        <h3>Success in the 1950s</h3>
                        <div class="question-box"><p>"Evaluate how successful the Civil Rights movement was in the 1950s."</p></div>
                    </div>
                    <div class="mission-card" onclick="location.href='assets/missions/CR_M3_workspace.html'">
                        <span class="mid-tag">Mission CR_M3</span>
                        <h3>Federal Institutions</h3>
                        <div class="question-box"><p>"Assess the impact of federal institutions on civil rights in the late 1940s and 1950s."</p></div>
                    </div>
                    <div class="mission-card" onclick="location.href='assets/missions/CR_M4_workspace.html'">
                        <span class="mid-tag">Mission CR_M4</span>
                        <h3>NAACP Effectiveness</h3>
                        <div class="question-box"><p>"Analyse the effectiveness of the NAACP in promoting civil rights in the late 1940s and 1950s."</p></div>
                    </div>
                    <div class="mission-card" onclick="location.href='assets/missions/CR_M5_workspace.html'">
                        <span class="mid-tag">Mission CR_M5</span>
                        <h3>Federal vs Grassroots</h3>
                        <div class="question-box"><p>"'Progress towards greater civil rights in the 1950s was mainly brought about by federal institutions.' Evaluate this view."</p></div>
                    </div>
                </div>
            </div>
        </div>

        <div class="header" id="header-section">
            <div style="color:#6c757d; font-size:11px; margin-bottom:5px;">
                MISSION ID: {mid}
                <span id="mode-badge" class="mode-badge" style="display:none;"></span>
            </div>
            <div style="display:flex; align-items:center; gap:10px;">
                <h1 class="q-text" id="question-title" contenteditable="true" spellcheck="false" style="outline:none; margin:0; flex:1;">{question}</h1>
                <span title="Click to edit the question" style="font-size:18px; color:#457b9d;">✏️</span>
            </div>
        </div>

        <div id="module-toolbar">
            <button class="toolbar-btn" onclick="addModule('intro')">+ Add Intro</button>
            <button class="toolbar-btn" onclick="addModule('body')">+ Add Body (PEEL)</button>
            <button class="toolbar-btn" onclick="addModule('conclusion')">+ Add Conclusion</button>
        </div>

        <div id="essay-constructor"></div>

        <div class="review-actions">
            <button class="ai-review-trigger" id="ai-btn" onclick="showPreviewView()" disabled style="opacity: 0.5; cursor: not-allowed;">🚀 SUBMIT FOR AI TEACHER'S REVIEW</button>
            <div id="submit-validation-hint" style="font-size: 12px; color: #6c757d; margin-top: 8px; text-align: center; min-height: 20px;"></div>
        </div>

        <!-- Preview View (直接显示，不再用 Modal) -->
        <div id="preview-view" style="display: none;">
            <div style="background: #fff; border-radius: 12px; padding: 30px; box-shadow: 0 4px 15px rgba(0,0,0,0.1); max-width: 1000px; width: 100%;">
                <div style="font-size: 24px; font-weight: 700; color: #1d3557; margin-bottom: 20px;">📄 Essay Preview</div>
                <div id="preview-content" style="max-height: 60vh; overflow-y: auto; padding: 20px; background: #f8f9fa; border-radius: 8px; line-height: 1.8; white-space: pre-wrap; margin-bottom: 20px;"></div>
                <div style="display: flex; gap: 12px; justify-content: flex-end;">
                    <button class="modal-btn modal-btn-secondary" onclick="backFromPreview()">← Back to Edit</button>
                    <button class="modal-btn modal-btn-primary" onclick="confirmSubmitFromPreview()">✓ Confirm & Submit for Review</button>
                </div>
        </div>
    </div>

        <!-- 批改视图：左右双栏（同屏对照修改） -->
        <div id="feedback-view">
            <div class="feedback-container">
                <div class="feedback-left">
                    <h3>
                        📝 Your Essay
                        <button class="view-mode-toggle" id="view-mode-toggle" onclick="toggleEditViewMode()">Switch to Text Mode</button>
                    </h3>
                    <div id="feedback-essay-editable"></div>
                </div>
                <div class="feedback-right">
                    <h3>🎯 Academic Review</h3>
                    <div id="ai-content" style="line-height: 1.8; font-size: 15px;">AI is analyzing...</div>
                </div>
            </div>
            <div style="margin-top: 20px; text-align: center;">
                <button class="ai-review-trigger" id="resubmit-btn" onclick="resubmitForReview()" style="display: none;">🔄 Re-submit for Improved Score</button>
            </div>
        </div>

        <!-- Visual Audit V3.1 结构化卡片系统 -->
        <div id="review-overlay" style="display: none; padding: 20px; background: #f8fafc;">
            <!-- 总分卡片 -->
            <div class="score-card" style="background: white; padding: 20px; border-radius: 12px; box-shadow: 0 4px 6px -1px rgb(0 0 0 / 0.1); margin-bottom: 20px; text-align: center;">
                <h1 id="overall-grade" style="font-size: 48px; margin: 0; color: #2563eb;"></h1>
                <div id="overall-score-text" style="font-weight: bold; margin: 10px 0;"></div>
                <p id="overall-summary" style="color: #475569; line-height: 1.6;"></p>
            </div>
        
            <!-- 评分维度网格 -->
            <div id="criteria-grid" style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin-bottom: 20px;"></div>
        
            <!-- 行动清单 -->
            <div id="action-list" style="margin-bottom: 20px;"></div>
        
            <!-- 段落诊断卡片 -->
            <div id="paragraph-cards" style="display: flex; flex-direction: column; gap: 20px; margin-bottom: 20px;"></div>
        
            <!-- 范文卡片 -->
            <div style="margin-bottom: 20px;">
                <button id="reveal-model-btn" onclick="toggleModelEssay()" style="width: 100%; padding: 16px; background: linear-gradient(135deg, #4F46E5 0%, #1e293b 100%); color: white; border: none; border-radius: 8px; font-size: 16px; font-weight: 700; cursor: pointer;">
                    📖 Reveal Model Essay
                </button>
                <div id="model-essay-content" style="display: none; margin-top: 20px; padding: 20px; background: #f8fafc; border-radius: 8px; line-height: 1.8; font-size: 14px; color: #1e293b; white-space: pre-wrap;"></div>
            </div>
        
            <!-- 操作按钮 -->
            <div style="margin-top: 30px; text-align: center;">
                <button class="ai-review-trigger" id="review-close-btn" onclick="closeReviewOverlay()" style="padding: 12px 24px; background: #64748b; color: white; border: none; border-radius: 8px; cursor: pointer; margin-right: 10px;">返回编辑</button>
                <button class="ai-review-trigger" id="review-resubmit-btn" onclick="resubmitForReview()" style="display: none; padding: 12px 24px; background: #e63946; color: white; border: none; border-radius: 8px; cursor: pointer;">🔄 重新提交</button>
            </div>
            
            <!-- 保留 review-container 用于向后兼容 -->
            <div id="review-container" style="max-width: 1000px; margin: 2rem auto; padding: 0 1rem; display: none;"></div>
        </div>

        <div id="export-preview">
            <div style="font-weight:700; margin-bottom:8px;">📄 Essay Preview</div>
            <div id="export-essay"></div>
        </div>
    </div>
    
    <!-- 侧边栏切换按钮 -->
    <button class="sidebar-toggle collapsed" id="sidebar-toggle" onclick="toggleSidebar()" title="Toggle Knowledge Hub">📚</button>
    
    <!-- 侧边栏遮罩层 -->
    <div class="sidebar-overlay" id="sidebar-overlay" onclick="closeSidebar()"></div>

    <!-- 可折叠侧边栏 -->
    <div class="sidebar" id="knowledge-sidebar">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 14px;">
            <h3 style="margin:0; color:#1d3557;">Knowledge Hub</h3>
            <button onclick="closeSidebar()" style="background: none; border: none; font-size: 20px; cursor: pointer; color: #6c757d; padding: 0; width: 24px; height: 24px; display: flex; align-items: center; justify-content: center;">✕</button>
        </div>
        <div class="sidebar-content">
            <div class="kb-section">
                <div style="font-size:12px; font-weight:800; color:#1d3557; margin-bottom:10px; border-bottom:1px solid #eee;">⚖️ LEGAL MILESTONES</div>
                    <div class="tag-row"><div class="tag" onclick="add('Brown v. Board (1954)')">Brown v. Board</div><button class="explain-btn" onclick="getExplanation('Brown v. Board')">💡</button></div>
                    <div class="tag-row"><div class="tag" onclick="add('Civil Rights Act (1957)')">1957 CR Act</div><button class="explain-btn" onclick="getExplanation('Civil Rights Act 1957')">💡</button></div>
            </div>

            <div class="kb-section" style="margin-top:20px;">
                <div style="font-size:12px; font-weight:800; color:#1d3557; margin-bottom:10px; border-bottom:1px solid #eee;">✊ DIRECT ACTION</div>
                    <div class="tag-row"><div class="tag" onclick="add('Montgomery Bus Boycott (1955–56)')">Bus Boycott</div><button class="explain-btn" onclick="getExplanation('Montgomery Bus Boycott')">💡</button></div>
                    <div class="tag-row"><div class="tag" onclick="add('Little Rock Nine (1957)')">Little Rock 9</div><button class="explain-btn" onclick="getExplanation('Little Rock Nine')">💡</button></div>
                    <div class="tag-row"><div class="tag" onclick="add('Jim Crow laws')">Jim Crow</div><button class="explain-btn" onclick="getExplanation('Jim Crow laws')">💡</button></div>
                </div>
            </div>

            <div id="explainer-window">
                <div style="font-weight:800; color:#a8dadc; font-size:11px; margin-bottom:8px; display:flex; justify-content:space-between;">
                    <span>👨‍🏫 KNOWLEDGE EXPLORER</span>
                    <span style="cursor:pointer" onclick="document.getElementById('explain-box').innerText='Click the 💡 button for detailed context.'">Reset</span>
                </div>
                <div id="explain-box">Click the 💡 button for detailed context.</div>
            </div>
        </div>
    </div>
    </div>

    <!-- Toast 容器 -->
    <div id="toast-container"></div>
    
    <!-- 全局字数统计气泡 -->
    <div class="global-word-count" id="global-word-count">0 words</div>
    
    <!-- Focus Modal -->
    <div class="focus-modal" id="focus-modal" onclick="if(event.target===this) closeFocusMode()">
        <div class="focus-modal-content" onclick="event.stopPropagation()">
            <div class="focus-modal-header">
                <div class="focus-modal-title" id="focus-modal-title">Focus Mode</div>
                <button class="focus-modal-close" onclick="closeFocusMode()">✕ Close</button>
            </div>
            <textarea 
                class="focus-textarea" 
                id="focus-textarea"
                placeholder="Write your content here..."
                oninput="onFocusInput(); updateFocusWordCount();"
            ></textarea>
            <div class="focus-modal-footer">
                <div class="focus-word-count" id="focus-word-count">0 words</div>
                <button class="focus-save-btn" onclick="saveFocusMode()">Save & Close</button>
            </div>
        </div>
    </div>


    <script>
        const ID = "{mid}";

        // --- 0. 全局状态 ---
        let currentLanguageMode = document.getElementById('language-setting').value || 'dual';
        let modules = []; // {{ id, type: 'intro'|'body'|'conclusion', boxes: [] }}
        let activeTextarea = null;
        let workspaceMode = 'practice'; // 'audit' or 'practice'

        const STORAGE_KEY = `GGV1_STATE::${{ID}}`;
        let saveDebounceTimer = null;

        // --- 0.0 模式检测与初始化 ---
        function detectWorkspaceMode() {{
            const mode = localStorage.getItem('workspaceMode') || 'practice';
            workspaceMode = mode;
            
            // 显示模式标签
            const badge = document.getElementById('mode-badge');
            if (badge) {{
                if (mode === 'audit') {{
                    badge.className = 'mode-badge audit';
                    badge.innerText = 'Audit Mode';
                    badge.style.display = 'inline-block';
                }} else {{
                    badge.className = 'mode-badge practice';
                    badge.innerText = 'Practice Mode';
                    badge.style.display = 'inline-block';
                }}
            }}
            
            // Audit Mode：隐藏题目背景和 Knowledge Hub
            if (mode === 'audit') {{
                const header = document.getElementById('header-section');
                const sidebar = document.querySelector('.sidebar');
                const sidebarToggle = document.getElementById('sidebar-toggle');
                const toolbar = document.getElementById('module-toolbar');
                
                if (header) header.style.display = 'none';
                if (sidebar) sidebar.style.display = 'none';
                if (sidebarToggle) sidebarToggle.style.display = 'none';
                if (toolbar) toolbar.style.display = 'none';
            }}
            
            return mode;
        }}

        // --- 0.1 实用函数 ---
        function getLanguageConstraint() {{
            if (currentLanguageMode === 'en') return "Constraint: You must respond in 100% English. Do not use any Chinese characters.";
            if (currentLanguageMode === 'zh') return "约束：必须 100% 使用中文回答，即使问题是英文。";
            return "约束：使用双语回答。采用‘中文核心解释 + 括号内对应英文专业术语’的格式。";
        }}

        function getCurrentQuestion() {{
            const title = document.getElementById('question-title');
            const text = (title?.innerText || "").trim();
            return text || "{question}";
        }}

        function setActiveTextarea(el) {{
            activeTextarea = el;
        }}

        // --- 0.2 模块与占位符 ---
        function makeModuleId() {{
            return 'm_' + Math.random().toString(36).slice(2, 9) + Date.now().toString(36);
        }}

        function getBoxConfig(type) {{
            if (type === 'intro') {{
                return [
                    {{ label: "Intro Box 1", placeholder: "Define issue & background... (e.g., The issue of [topic] was significant...)" }},
                    {{ label: "Intro Box 2", placeholder: "Show debate... (e.g., Historians have debated...)" }},
                    {{ label: "Intro Box 3", placeholder: "Thesis statement... (e.g., This essay will argue that...)" }}
                ];
            }} else if (type === 'conclusion') {{
                return [
                    {{ label: "Conclusion Box 1", placeholder: "Direct answer (In conclusion...)" }},
                    {{ label: "Conclusion Box 2", placeholder: "Weighting judgement (Their impact was mainly...)" }},
                    {{ label: "Conclusion Box 3", placeholder: "Final evaluation (While [success], [limitation]...)" }}
                ];
            }} else {{
                return [
                    {{ label: "PEEL Box 1", placeholder: "Point (One important way...)" }},
                    {{ label: "PEEL Box 2", placeholder: "Evidence (This can be seen in...)" }},
                    {{ label: "PEEL Box 3", placeholder: "Explain (This was important because...)" }},
                    {{ label: "PEEL Box 4", placeholder: "Link back (Therefore, this shows...)" }}
                ];
            }}
        }}

        function createEmptyModule(type) {{
            const cfg = getBoxConfig(type);
            return {{
                id: makeModuleId(),
                type,
                boxes: new Array(cfg.length).fill(""),
                mode: 'guided',
                freeText: ""
            }};
        }}

        // --- 0.3 保存 / 恢复 ---
        function getState() {{
            return {{
                question: getCurrentQuestion(),
                language: currentLanguageMode,
                examType: currentExamType,
                modules,
                updatedAt: Date.now()
            }};
        }}

        function saveToLocal() {{
            try {{
                localStorage.setItem(STORAGE_KEY, JSON.stringify(getState()));
            }} catch (e) {{}}
        }}

        function scheduleSave() {{
            if (saveDebounceTimer) clearTimeout(saveDebounceTimer);
            saveDebounceTimer = setTimeout(() => saveToLocal(), 2000);
        }}

        function loadFromLocal() {{
            try {{
                const raw = localStorage.getItem(STORAGE_KEY);
                if (!raw) return;
                const s = JSON.parse(raw);
                if (s.question) document.getElementById('question-title').innerText = s.question;
                if (s.language) {{
                    currentLanguageMode = s.language;
                    document.getElementById('language-setting').value = s.language;
                }}
                if (s.examType) {{
                    currentExamType = s.examType;
                    const examSelector = document.getElementById('exam-type-selector');
                    if (examSelector) examSelector.value = s.examType;
                }}
                if (Array.isArray(s.modules) && s.modules.length) {{
                    modules = s.modules;
                }}
            }} catch (e) {{}}
        }}

        // --- 1. 模块渲染与编辑 ---
        function renderModules() {{
            const container = document.getElementById('essay-constructor');
            if (!container) return;

            if (!modules.length) {{
                container.innerHTML = '<div style="color:#6c757d; font-size:13px;">Use the buttons above to add an Intro, Body paragraph, or Conclusion.</div>';
                return;
            }}

            let bodyIndex = 0;
            let introIndex = 0;
            let conclusionIndex = 0;
            const html = modules.map((m) => {{
                const cfg = getBoxConfig(m.type);
                const isFree = m.mode === 'free';
                let label = "";
                let blockId = "";
                if (m.type === 'intro') {{
                    introIndex += 1;
                    label = "Intro";
                    blockId = `intro-${{introIndex}}`;
                }} else if (m.type === 'conclusion') {{
                    conclusionIndex += 1;
                    label = "Conclusion";
                    blockId = `conclusion-${{conclusionIndex}}`;
                }} else {{
                    bodyIndex += 1;
                    label = "Body Paragraph " + bodyIndex;
                    blockId = `body-${{bodyIndex}}`;
                }}

                const modeLabel = isFree ? 'Free' : 'Guided';
                const modeIcon = isFree ? '📝' : '🧩';

                let bodyHtml = "";
                if (isFree) {{
                    const freeText = (m.freeText || (Array.isArray(m.boxes) ? m.boxes.join(" ") : ""));
                    const hintLines = getBoxConfig(m.type).map((c, i) => (i + 1) + '. ' + c.placeholder).join('<br>');
                    const wordCount = countWords(freeText);
                    bodyHtml = `
                        <div class="editor-box">
                            <div class="label">Freeform ${{label}}</div>
                            <textarea
                                data-module="${{m.id}}"
                                data-free="1"
                                placeholder="Write your ${{label.toLowerCase()}} in full sentences here..."
                                onfocus="setActiveTextarea(this)"
                                oninput="onFreeInput('${{m.id}}', this.value); updateWordCount(this);"
                            >${{freeText}}</textarea>
                            <div class="word-count">${{wordCount}} words</div>
                            <div class="free-hint">${{hintLines}}</div>
                        </div>
                    `;
                }} else {{
                    const boxesHtml = cfg.map((boxCfg, idx) => {{
                        const value = (m.boxes && typeof m.boxes[idx] === 'string') ? m.boxes[idx] : "";
                        const wordCount = countWords(value);
                        return `
                            <div class="editor-box">
                                <div class="label">${{boxCfg.label}}</div>
                                <textarea 
                                    data-module="${{m.id}}" 
                                    data-box="${{idx}}" 
                                    placeholder="${{boxCfg.placeholder}}"
                                    onfocus="setActiveTextarea(this)"
                                    oninput="onBoxInput('${{m.id}}', ${{idx}}, this.value); updateWordCount(this);"
                                >${{value}}</textarea>
                                <div class="word-count">${{wordCount}} words</div>
                            </div>
                        `;
                    }}).join("");
                    bodyHtml = boxesHtml;
                }}

                return `
                    <div class="essay-module" data-id="${{m.id}}" data-block-id="${{blockId}}">
                        <div class="module-header">
                            <div class="module-controls-left">
                                <button class="move-btn" onclick="moveModule('${{m.id}}', -1)">↑</button>
                                <button class="move-btn" onclick="moveModule('${{m.id}}', 1)">↓</button>
                                <span class="module-tag">${{label}}</span>
                            </div>
                            <div class="module-controls-right">
                                <button class="focus-btn" onclick="openFocusMode('${{m.id}}')" title="Focus Mode">🔍</button>
                                <button class="mode-toggle" onclick="toggleModuleMode('${{m.id}}')">${{modeIcon}} ${{modeLabel}}</button>
                                <button class="module-delete" onclick="confirmRemoveModule('${{m.id}}')">✕</button>
                            </div>
                        </div>
                        ${{bodyHtml}}
                    </div>
                `;
            }}).join("");

            container.innerHTML = html;
        }}

        function addModule(type) {{
            modules.push(createEmptyModule(type));
            renderModules();
            saveToLocal();
        }}

        function removeModule(id) {{
            modules = modules.filter(m => m.id !== id);
            renderModules();
            saveToLocal();
        }}

        function confirmRemoveModule(id) {{
            if (confirm('Delete this module? This action cannot be undone.')) {{
                removeModule(id);
            }}
        }}

        function onBoxInput(id, index, value) {{
            const m = modules.find(m => m.id === id);
            if (!m) return;
            if (!Array.isArray(m.boxes)) m.boxes = [];
            m.boxes[index] = value;
            scheduleSave();
            updateGlobalWordCount();
        }}
        
        function onFreeInput(id, value) {{
            const m = modules.find(m => m.id === id);
            if (!m) return;
            m.freeText = value;
            scheduleSave();
            updateGlobalWordCount();
        }}
        
        // --- 核心计算逻辑（与 DOM 解耦，便于迁移到小程序）---
        
        /**
         * 计算文本字数（纯函数，无 DOM 依赖）
         * @param {{string}} text - 待统计的文本
         * @returns {{number}} 字数
         */
        function countWords(text) {{
            if (!text || !text.trim()) return 0;
            return text.trim().split(/\\s+/).filter(w => w.length > 0).length;
        }}
        
        /**
         * 计算单个模块的字数（纯函数）
         * @param {{Object}} module - 模块对象
         * @returns {{number}} 该模块的字数
         */
        function calculateModuleWordCount(module) {{
            if (!module) return 0;
            if (module.mode === 'free') {{
                return countWords(module.freeText || '');
            }} else if (Array.isArray(module.boxes)) {{
                return module.boxes.reduce((total, box) => total + countWords(box || ''), 0);
            }}
            return 0;
        }}
        
        /**
         * 计算所有模块的总字数（纯函数）
         * @param {{Array}} modulesArray - 模块数组
         * @returns {{number}} 总字数
         */
        function calculateTotalWordCount(modulesArray) {{
            if (!Array.isArray(modulesArray)) return 0;
            return modulesArray.reduce((total, m) => total + calculateModuleWordCount(m), 0);
        }}
        
        /**
         * 分析 PEEL 结构（纯函数）
         * @param {{Array}} modulesArray - 模块数组
         * @returns {{Object}} 结构分析结果
         */
        function analyzePEELStructure(modulesArray) {{
            if (!Array.isArray(modulesArray)) return {{ intro: 0, body: 0, conclusion: 0, total: 0 }};
            
            const analysis = {{
                intro: 0,
                body: 0,
                conclusion: 0,
                total: modulesArray.length,
                modules: modulesArray.map(m => ({{
                    type: m.type,
                    wordCount: calculateModuleWordCount(m),
                    mode: m.mode || 'guided'
                }}))
            }};
            
            modulesArray.forEach(m => {{
                if (m.type === 'intro') analysis.intro++;
                else if (m.type === 'body') analysis.body++;
                else if (m.type === 'conclusion') analysis.conclusion++;
            }});
            
            return analysis;
        }}
        
        /**
         * 构建完整 Essay 文本（纯函数）
         * @param {{Array}} modulesArray - 模块数组
         * @returns {{string}} 完整的 Essay 文本
         */
        function buildEssayTextFromModules(modulesArray) {{
            if (!Array.isArray(modulesArray)) return '';
            
            const parts = [];
            modulesArray.forEach((m) => {{
                let text = "";
                if (m.mode === 'free') {{
                    // Free 模式：直接使用 freeText
                    text = (m.freeText || "").trim();
                }} else if (Array.isArray(m.boxes)) {{
                    // Guided 模式：遍历所有 boxes（P, E, E, L），确保完整合并
                    text = m.boxes
                        .map(b => (b || "").trim())
                        .filter(Boolean)
                        .join(" ");
                }}
                if (!text) return;
                let prefix = "";
                if (m.type === 'intro') prefix = "[Intro] ";
                else if (m.type === 'conclusion') prefix = "[Conclusion] ";
                else prefix = "[Body] ";
                parts.push(prefix + text);
            }});
            return parts.join("\\n\\n");
        }}
        
        /**
         * 获取结构摘要（纯函数）
         * @param {{Array}} modulesArray - 模块数组
         * @returns {{Array}} 结构摘要数组
         */
        function getStructureSummaryFromModules(modulesArray) {{
            if (!Array.isArray(modulesArray)) return [];
            
            return modulesArray.map((m) => ({{
                type: m.type,
                text: m.mode === 'free'
                    ? (m.freeText || "").trim()
                    : (Array.isArray(m.boxes) ? m.boxes.join(" ").trim() : "")
            }}));
        }}
        
        // --- DOM 更新函数（依赖核心计算逻辑）---
        
        function updateWordCount(textarea) {{
            const wordCountEl = textarea.parentElement.querySelector('.word-count');
            if (wordCountEl) {{
                const count = countWords(textarea.value);
                wordCountEl.textContent = count + ' words';
            }}
        }}
        
        function updateGlobalWordCount() {{
            const globalCountEl = document.getElementById('global-word-count');
            if (!globalCountEl) return;
            
            const totalWords = calculateTotalWordCount(modules);
            globalCountEl.textContent = totalWords + ' words';
            
            // [Agent-02 守门员] 实时校验并更新提交按钮状态
            validateSubmission();
        }}
        
        /**
         * [Agent-02 守门员] 校验提交条件
         * @returns {{Object}} 校验结果对象
         */
        function validateSubmission() {{
            const essayText = buildEssayText();
            const totalWords = calculateTotalWordCount(modules);
            const hintEl = document.getElementById('submit-validation-hint');
            const submitBtn = document.getElementById('ai-btn');
            
            if (!hintEl || !submitBtn) return {{ valid: false, reason: '' }};
            
            // 1. 字数校验
            if (totalWords === 0) {{
                submitBtn.disabled = true;
                submitBtn.style.opacity = '0.5';
                submitBtn.style.cursor = 'not-allowed';
                hintEl.textContent = '⚠️ 禁止 0 字提交';
                hintEl.style.color = '#e63946';
                return {{ valid: false, reason: 'zero_words' }};
            }}
            
            if (totalWords < 50) {{
                submitBtn.disabled = true;
                submitBtn.style.opacity = '0.5';
                submitBtn.style.cursor = 'not-allowed';
                const remaining = 50 - totalWords;
                hintEl.textContent = `⚠️ 内容过短，AI 无法进行有效诊断。还差 ${{remaining}} 词即可提交`;
                hintEl.style.color = '#f4a261';
                return {{ valid: false, reason: 'too_short', remaining }};
            }}
            
            // 2. 段落结构校验（至少 2 个明显的换行，代表 Intro + Body）
            const paragraphs = essayText.split(/\\n\\s*\\n/).filter(p => p.trim().length > 0);
            const hasMultipleParagraphs = paragraphs.length >= 2;
            
            if (!hasMultipleParagraphs) {{
                // 检查是否有至少 2 个换行符（包括单个换行）
                const lineBreaks = (essayText.match(/\\n/g) || []).length;
                if (lineBreaks < 2) {{
                    submitBtn.disabled = true;
                    submitBtn.style.opacity = '0.5';
                    submitBtn.style.cursor = 'not-allowed';
                    hintEl.textContent = '⚠️ 建议至少包含开头段与一个正文段以符合 A-Level 评审标准';
                    hintEl.style.color = '#f4a261';
                    return {{ valid: false, reason: 'insufficient_paragraphs' }};
                }}
            }}
            
            // 3. 非法输入拦截
            const trimmedText = essayText.trim();
            
            // 检查是否为纯数字
            if (/^\\d+$/.test(trimmedText.replace(/\\s/g, ''))) {{
                submitBtn.disabled = true;
                submitBtn.style.opacity = '0.5';
                submitBtn.style.cursor = 'not-allowed';
                hintEl.textContent = '⚠️ 检测到非法输入（纯数字），请输入有效的文章内容';
                hintEl.style.color = '#e63946';
                return {{ valid: false, reason: 'numbers_only' }};
            }}
            
            // 检查是否为重复乱码字符（如 "aaaaa..."）
            const uniqueChars = new Set(trimmedText.replace(/\\s/g, ''));
            if (uniqueChars.size <= 2 && trimmedText.length > 10) {{
                // 如果只有 1-2 个不同字符且文本较长，可能是乱码
                const charCounts = {{}};
                for (const char of trimmedText.replace(/\\s/g, '')) {{
                    charCounts[char] = (charCounts[char] || 0) + 1;
                }}
                const maxCount = Math.max(...Object.values(charCounts));
                const totalChars = trimmedText.replace(/\\s/g, '').length;
                // 如果某个字符占比超过 80%，可能是乱码
                if (maxCount / totalChars > 0.8) {{
                    submitBtn.disabled = true;
                    submitBtn.style.opacity = '0.5';
                    submitBtn.style.cursor = 'not-allowed';
                    hintEl.textContent = '⚠️ 检测到非法输入（重复字符），请输入有效的文章内容';
                    hintEl.style.color = '#e63946';
                    return {{ valid: false, reason: 'repeated_chars' }};
                }}
            }}
            
            // 所有校验通过
            submitBtn.disabled = false;
            submitBtn.style.opacity = '1';
            submitBtn.style.cursor = 'pointer';
            hintEl.textContent = '✅ 可以提交评审';
            hintEl.style.color = '#2a9d8f';
            return {{ valid: true }};
        }}
        
        // --- Focus Mode 功能 ---
        let currentFocusModuleId = null;
        
        function openFocusMode(moduleId) {{
            const m = modules.find(m => m.id === moduleId);
            if (!m) return;
            
            currentFocusModuleId = moduleId;
            const modal = document.getElementById('focus-modal');
            const textarea = document.getElementById('focus-textarea');
            const title = document.getElementById('focus-modal-title');
            
            if (!modal || !textarea || !title) return;
            
            // 确定标签
            let label = "";
            if (m.type === 'intro') label = "Intro";
            else if (m.type === 'conclusion') label = "Conclusion";
            else {{
                const bodyIdx = modules.filter(mm => mm.type === 'body' && modules.indexOf(mm) <= modules.indexOf(m)).length;
                label = "Body Paragraph " + bodyIdx;
            }}
            
            title.textContent = `Focus Mode: ${{label}}`;
            
            // 获取内容
            let content = "";
            if (m.mode === 'free') {{
                content = m.freeText || "";
            }} else if (Array.isArray(m.boxes)) {{
                content = m.boxes.map(b => (b || "").trim()).filter(Boolean).join("\\n\\n");
            }}
            
            textarea.value = content;
            updateFocusWordCount();
            
            modal.classList.add('visible');
            textarea.focus();
        }}
        
        function closeFocusMode() {{
            const modal = document.getElementById('focus-modal');
            if (modal) {{
                modal.classList.remove('visible');
            }}
            currentFocusModuleId = null;
        }}
        
        function onFocusInput() {{
            // Focus Mode 下的输入实时更新（但不立即保存到模块，等 Save 时再保存）
        }}
        
        function updateFocusWordCount() {{
            const textarea = document.getElementById('focus-textarea');
            const countEl = document.getElementById('focus-word-count');
            if (textarea && countEl) {{
                const count = countWords(textarea.value);
                countEl.textContent = count + ' words';
            }}
        }}
        
        function saveFocusMode() {{
            if (!currentFocusModuleId) return;
            
            const m = modules.find(m => m.id === currentFocusModuleId);
            const textarea = document.getElementById('focus-textarea');
            if (!m || !textarea) return;
            
            const content = textarea.value;
            
            if (m.mode === 'free') {{
                m.freeText = content;
            }} else {{
                // 如果是 Guided 模式，按段落拆分回 boxes
                const paragraphs = content.split(/\\n{{2,}}|\\n/).filter(p => p.trim());
                const cfg = getBoxConfig(m.type);
                m.boxes = new Array(cfg.length).fill("");
                for (let i = 0; i < cfg.length && i < paragraphs.length; i++) {{
                    m.boxes[i] = paragraphs[i];
                }}
            }}
            
            saveToLocal();
            renderModules();
            updateGlobalWordCount();
            closeFocusMode();
        }}

        function toggleModuleMode(id) {{
            // 致命 Bug 修复：切换前强制保存
            saveToLocal();
            
            const m = modules.find(m => m.id === id);
            if (!m) return;
            const cfg = getBoxConfig(m.type);
            if (!m.mode || m.mode === 'guided') {{
                const parts = Array.isArray(m.boxes) ? m.boxes.map(b => (b || '').trim()).filter(Boolean) : [];
                m.freeText = parts.join("\\n\\n");
                m.mode = 'free';
            }} else {{
                const maxBoxes = cfg.length;
                const src = (m.freeText || '').split(/\\n{{2,}}|\\n/).filter(Boolean);
                m.boxes = new Array(maxBoxes).fill("");
                for (let i = 0; i < maxBoxes; i++) {{
                    if (i < src.length - 1) {{
                        m.boxes[i] = src[i];
                    }} else if (i === maxBoxes - 1 && src.length) {{
                        m.boxes[i] = src.slice(i).join(' ');
                        break;
                    }}
                }}
                m.mode = 'guided';
            }}
            
            // 渲染新模式的 DOM
            renderModules();
            
            // 重新绑定事件监听器（确保字数统计等功能正常工作）
            setTimeout(() => {{
                updateGlobalWordCount();
                // 重新绑定所有 textarea 的 input 事件
                document.querySelectorAll('textarea[data-module]').forEach(textarea => {{
                    if (!textarea.hasAttribute('data-listener-bound')) {{
                        textarea.setAttribute('data-listener-bound', 'true');
                        textarea.addEventListener('input', () => {{
                            updateGlobalWordCount();
                            updateWordCount(textarea);
                        }});
                    }}
                }});
            }}, 100);
        }}

        function moveModule(id, direction) {{
            const idx = modules.findIndex(m => m.id === id);
            if (idx === -1) return;
            const next = idx + direction;
            if (next < 0 || next >= modules.length) return;
            const tmp = modules[idx];
            modules[idx] = modules[next];
            modules[next] = tmp;
            renderModules();
            saveToLocal();
        }}

        // --- 2. 全文构建（使用核心计算逻辑）---
        function buildEssayText() {{
            return buildEssayTextFromModules(modules);
        }}

        function getStructureSummary() {{
            return getStructureSummaryFromModules(modules);
        }}

        function buildEssayHtml() {{
            const parts = [];
            let bodyIndex = 0;
            modules.forEach((m) => {{
                let title = "";
                if (m.type === 'intro') title = "Introduction";
                else if (m.type === 'conclusion') title = "Conclusion";
                else {{
                    bodyIndex += 1;
                    title = "Body Paragraph " + bodyIndex;
                }}
                let text = "";
                if (m.mode === 'free') {{
                    text = (m.freeText || "").trim();
                }} else if (Array.isArray(m.boxes)) {{
                    text = m.boxes.map(b => (b || "").trim()).filter(Boolean).join(" ");
                }}
                if (!text) return;
                const safe = text.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/\\n/g, '<br>');
                parts.push(
                    `<h4 style="margin:8px 0 4px 0;">${{title}}</h4>` +
                    `<p style="margin:0 0 8px 0;">${{safe}}</p>`
                );
            }});
            return parts.join('');
        }}

        // --- 3. 语言与自动保存事件 ---
        document.getElementById('language-setting').addEventListener('change', (e) => {{
            currentLanguageMode = e.target.value;
            saveToLocal();
        }});

        const examTypeSelector = document.getElementById('exam-type-selector');
        if (examTypeSelector) {{
            examTypeSelector.addEventListener('change', (e) => {{
                currentExamType = e.target.value;
                saveToLocal();
            }});
        }}

        document.getElementById('question-title').addEventListener('blur', () => saveToLocal());

        // --- 4. 知识 Hub 插入：针对当前激活 textarea ---
        function add(text) {{
            if (!activeTextarea) return;
            const start = activeTextarea.selectionStart ?? activeTextarea.value.length;
            const end = activeTextarea.selectionEnd ?? start;
            const v = activeTextarea.value;
            activeTextarea.value = v.substring(0, start) + text + " " + v.substring(end);
            activeTextarea.focus();

            const mId = activeTextarea.getAttribute('data-module');
            const idxStr = activeTextarea.getAttribute('data-box');
            const idx = idxStr ? parseInt(idxStr, 10) : NaN;
            if (mId && !Number.isNaN(idx)) {{
                onBoxInput(mId, idx, activeTextarea.value);
            }}
        }}

        // --- 5. 侧边栏讲解老师 ---
        async function getExplanation(topic) {{
            const box = document.getElementById('explain-box');
            const lang = currentLanguageMode;
            const constraint = getLanguageConstraint();
            const essay_question = getCurrentQuestion();
            box.innerHTML = `<i style="color:#666">🔍 Searching...</i>`;
            try {{
                const response = await fetch('/api/explain', {{
                    method: 'POST',
                    headers: {{ 'Content-Type': 'application/json' }},
                    body: JSON.stringify({{ 
                        topic,
                        language: lang,
                        essay_question,
                        structure: getStructureSummary(),
                        constraint
                    }})
                }});
                const result = await response.json();
                box.innerText = result.explanation || "No explanation found.";
            }} catch (e) {{ box.innerText = "⚠️ Connection error."; }}
        }}

        // --- 6. 预览视图逻辑（精简流程：直接显示，无 Modal） ---
        function showPreviewView() {{
            // [Agent-02 守门员] 提交前再次校验
            const validation = validateSubmission();
            if (!validation.valid) {{
                // 显示错误提示
                const hintEl = document.getElementById('submit-validation-hint');
                if (hintEl) {{
                    hintEl.style.animation = 'shake 0.5s';
                    setTimeout(() => {{ hintEl.style.animation = ''; }}, 500);
                }}
                return;
            }}
            
            const previewView = document.getElementById('preview-view');
            const content = document.getElementById('preview-content');
            if (!previewView || !content) return;
            
            const essayText = buildEssayText();
            if (!essayText.trim()) {{
                alert('Please write something before previewing.');
                return;
            }}
            
            // 格式化文本：按段落清晰排版
            const formatted = essayText
                .split('\\n\\n')
                .map(p => p.trim())
                .filter(p => p.length > 0)
                .join('\\n\\n');
            
            content.innerText = formatted;
            
            // 隐藏编辑区，显示预览视图
            document.getElementById('essay-constructor').style.display = 'none';
            document.getElementById('module-toolbar').style.display = 'none';
            document.querySelector('.review-actions').style.display = 'none';
            previewView.style.display = 'block';
            previewView.scrollIntoView({{ behavior: 'smooth' }});
        }}

        function backFromPreview() {{
            const previewView = document.getElementById('preview-view');
            const constructor = document.getElementById('essay-constructor');
            const toolbar = document.getElementById('module-toolbar');
            const actions = document.querySelector('.review-actions');
            
            if (previewView) previewView.style.display = 'none';
            if (constructor) constructor.style.display = 'block';
            if (toolbar) toolbar.style.display = 'flex';
            if (actions) actions.style.display = 'flex';
            
            constructor.scrollIntoView({{ behavior: 'smooth' }});
        }}

        async function confirmSubmitFromPreview() {{
            console.log('🚀 confirmSubmitFromPreview 函数被调用');
            
            // ===== 实现清空逻辑：函数开始时立即清空所有容器 =====
            const reviewOverlay = document.getElementById('review-overlay');
            const containersToClear = [
                'overall-grade',
                'overall-score-text',
                'overall-summary',
                'criteria-grid',
                'action-list',
                'paragraph-cards',
                'model-essay-content',
                'review-container',
                'review-overall-score',
                'review-dimension-scores',
                'review-diagnostics'
            ];
            
            // 清空所有容器内容并重置样式
            containersToClear.forEach(id => {{
                const el = document.getElementById(id);
                if (el) {{
                    // 单一数据源：使用 innerHTML 替换而非追加
                    el.innerHTML = '';
                    
                    // 重置样式：清除所有调试样式
                    el.style.display = '';
                    el.style.visibility = '';
                    el.style.height = '';
                    el.style.minHeight = '';
                    el.style.maxHeight = '';
                    el.style.opacity = '';
                    el.style.border = '';
                    el.style.borderRadius = '';
                    el.style.padding = '';
                    el.style.margin = '';
                    el.style.backgroundColor = '';
                    el.style.color = '';
                    el.style.fontSize = '';
                    el.style.fontWeight = '';
                    el.style.textAlign = '';
                    el.style.position = '';
                    el.style.zIndex = '';
                    el.style.overflow = '';
                    el.style.transform = '';
                    el.style.boxShadow = '';
                }}
            }});
            
            // 重置 review-overlay 的样式和内容
            if (reviewOverlay) {{
                // 清空 review-overlay 中可能存在的临时调试内容
                // 注意：不要清空 review-overlay.innerHTML，因为我们需要保留其结构
                // 只清空子容器，不破坏 HTML 结构
                
                // 重置样式：清除所有调试样式
                reviewOverlay.style.display = '';
                reviewOverlay.style.visibility = '';
                reviewOverlay.style.height = '';
                reviewOverlay.style.minHeight = '';
                reviewOverlay.style.maxHeight = '';
                reviewOverlay.style.opacity = '';
                reviewOverlay.style.border = '';
                reviewOverlay.style.borderRadius = '';
                reviewOverlay.style.padding = '';
                reviewOverlay.style.margin = '';
                reviewOverlay.style.backgroundColor = '';
                reviewOverlay.style.position = '';
                reviewOverlay.style.zIndex = '';
                reviewOverlay.style.overflow = '';
                reviewOverlay.style.transform = '';
                reviewOverlay.style.boxShadow = '';
                
                // 清理 review-overlay 中可能存在的临时调试容器
                // 查找所有可能的临时容器（通过类名或 ID 模式）
                const tempContainers = reviewOverlay.querySelectorAll('[id*="debug"], [id*="temp"], [id*="test"], [class*="debug"], [class*="temp"]');
                tempContainers.forEach(temp => {{
                    if (temp && temp.parentNode) {{
                        temp.parentNode.removeChild(temp);
                    }}
                }});
            }}
            
            console.log('✅ 所有容器已清空，样式已重置');
            
            // 1. 收集输入内容
            const essay = buildEssayText();
            const question = getCurrentQuestion();
            
            console.log('📝 收集到的内容:', {{ essayLength: essay.length, questionLength: question.length }});
            
            if (!essay || !essay.trim()) {{
                alert('⚠️ 请先输入文章内容');
                return;
            }}
            
            // 2. 检查 renderVisualAuditV3 是否已加载
            if (typeof window.renderVisualAuditV3 !== 'function') {{
                console.error('❌ renderVisualAuditV3 函数未找到');
                alert('⚠️ 渲染函数未加载，请确保 visual_audit_v3.js 已正确加载');
                return;
            }}
            console.log('✅ renderVisualAuditV3 函数已找到');
            
            // 3. 显示 Loading 状态
            const previewView = document.getElementById('preview-view');
            const constructor = document.getElementById('essay-constructor');
            const toolbar = document.getElementById('module-toolbar');
            const reviewActions = document.querySelector('.review-actions');
            
            // 隐藏输入区和预览区
            if (previewView) previewView.style.display = 'none';
            if (constructor) constructor.style.display = 'none';
            if (toolbar) toolbar.style.display = 'none';
            if (reviewActions) reviewActions.style.display = 'none';
            
            // 显示 review-overlay 和 Loading
            if (reviewOverlay) {{
                // 强制显示 review-overlay（仅设置必要的显示属性）
                reviewOverlay.style.display = 'block';
                reviewOverlay.style.visibility = 'visible';
                
                // 显示 Loading 状态
                const reviewContainer = document.getElementById('review-container');
                if (reviewContainer) {{
                    reviewContainer.style.display = 'block';
                    reviewContainer.style.visibility = 'visible';
                    // 单一数据源：使用 innerHTML 替换
                    reviewContainer.innerHTML = `
                        <div style="text-align: center; padding: 60px 20px;">
                            <div style="font-size: 48px; margin-bottom: 20px;">⏳</div>
                            <h2 style="color: #1e293b; margin-bottom: 12px;">AI 正在评审中...</h2>
                            <p style="color: #64748b;">请稍候，我们正在分析您的文章</p>
                        </div>
                    `;
                }}
            }}
            
            // 4. 确定 API 地址（支持本地和生产环境）
            const isLocalhost = window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1';
            const apiUrl = isLocalhost ? 'http://localhost:3000/api/review' : '/api/review';
            console.log('🌐 API 地址:', apiUrl);
            console.log('正在请求 Agent 评分...');
            
            // 5. 发送请求到 /api/review
            try {{
                const requestBody = {{
                    essay: essay,
                    question: question,
                    language: currentLanguageMode || 'en'
                }};
                console.log('📤 请求体:', {{ essayLength: requestBody.essay.length, question: requestBody.question }});
                
                const response = await fetch(apiUrl, {{
                    method: 'POST',
                    headers: {{
                        'Content-Type': 'application/json'
                    }},
                    body: JSON.stringify(requestBody)
                }});
                
                console.log('📥 收到响应:', {{ status: response.status, statusText: response.statusText, ok: response.ok }});
                
                if (!response.ok) {{
                    const errorText = await response.text();
                    console.error('❌ HTTP 错误:', {{ status: response.status, errorText }});
                    throw new Error(`HTTP error! status: ${{response.status}}, message: ${{errorText}}`);
                }}
                
                const responseData = await response.json();
                console.log('收到评分数据:', responseData);
                
                // 检查响应数据格式
                if (!responseData) {{
                    throw new Error('API 返回空数据');
                }}
                
                // 6. 确保数据脱壳：后端返回的可能是 {{ "structured": {{ ... }} }}
                const finalData = responseData.structured || responseData;
                console.log('📊 脱壳后的数据:', finalData);
                
                // 验证脱壳后的数据格式
                if (!finalData || !finalData.overall) {{
                    console.warn('⚠️ 响应数据格式异常:', responseData);
                    throw new Error('API 返回数据格式不正确，缺少 overall 字段');
                }
                
                console.log('✅ 数据验证通过，准备渲染');
                
                // ===== 在调用 renderVisualAuditV3 前再次清空并重置 =====
                // 确保渲染前所有容器都是干净的状态
                const containersToClearBeforeRender = [
                    'overall-grade',
                    'overall-score-text',
                    'overall-summary',
                    'criteria-grid',
                    'action-list',
                    'paragraph-cards',
                    'model-essay-content',
                    'review-container',
                    'review-overall-score',
                    'review-dimension-scores',
                    'review-diagnostics'
                ];
                
                containersToClearBeforeRender.forEach(id => {{
                    const el = document.getElementById(id);
                    if (el) {{
                        // 单一数据源：使用 innerHTML 替换而非追加
                        el.innerHTML = '';
                        
                        // 重置样式：清除所有调试和临时样式
                        el.style.display = '';
                        el.style.visibility = '';
                        el.style.height = '';
                        el.style.minHeight = '';
                        el.style.maxHeight = '';
                        el.style.opacity = '';
                        el.style.border = '';
                        el.style.borderRadius = '';
                        el.style.padding = '';
                        el.style.margin = '';
                        el.style.backgroundColor = '';
                        el.style.color = '';
                        el.style.fontSize = '';
                        el.style.fontWeight = '';
                        el.style.textAlign = '';
                        el.style.position = '';
                        el.style.zIndex = '';
                        el.style.overflow = '';
                        el.style.transform = '';
                        el.style.boxShadow = '';
                    }}
                }});
                
                // 重置 review-overlay 的样式（保留必要的显示属性）
                if (reviewOverlay) {{
                    // 清理 review-overlay 中可能存在的临时调试容器
                    const tempContainers = reviewOverlay.querySelectorAll('[id*="debug"], [id*="temp"], [id*="test"], [class*="debug"], [class*="temp"]');
                    tempContainers.forEach(temp => {{
                        if (temp && temp.parentNode) {{
                            temp.parentNode.removeChild(temp);
                        }}
                    }});
                    
                    // 只保留必要的显示属性，清除其他调试样式
                    reviewOverlay.style.display = 'block';
                    reviewOverlay.style.visibility = 'visible';
                    // 清除可能影响布局的调试样式
                    reviewOverlay.style.height = '';
                    reviewOverlay.style.minHeight = '';
                    reviewOverlay.style.maxHeight = '';
                    reviewOverlay.style.border = '';
                    reviewOverlay.style.borderRadius = '';
                    reviewOverlay.style.padding = '';
                    reviewOverlay.style.margin = '';
                    reviewOverlay.style.backgroundColor = '';
                    reviewOverlay.style.position = '';
                    reviewOverlay.style.zIndex = '';
                    reviewOverlay.style.overflow = '';
                    reviewOverlay.style.transform = '';
                    reviewOverlay.style.boxShadow = '';
                    
                    // 确保所有直接子元素也重置样式
                    Array.from(reviewOverlay.children).forEach(child => {{
                        if (child.style) {{
                            // 只保留必要的显示属性
                            child.style.display = '';
                            child.style.visibility = '';
                            // 清除调试样式
                            child.style.height = '';
                            child.style.minHeight = '';
                            child.style.maxHeight = '';
                            child.style.border = '';
                            child.style.borderRadius = '';
                            child.style.padding = '';
                            child.style.margin = '';
                            child.style.backgroundColor = '';
                            child.style.position = '';
                            child.style.zIndex = '';
                            child.style.overflow = '';
                            child.style.transform = '';
                            child.style.boxShadow = '';
                        }}
                    }});
                }}
                
                console.log('✅ 渲染前清空完成，所有样式已重置，临时容器已清理');
                
                // 7. 强制显示 review-overlay 及其所有子容器
                if (reviewOverlay) {{
                    // 移除所有可能隐藏的样式
                    reviewOverlay.style.display = 'block';
                    reviewOverlay.style.visibility = 'visible';
                    reviewOverlay.style.height = 'auto';
                    reviewOverlay.style.opacity = '1';
                    reviewOverlay.style.position = '';
                    
                    // 确保所有直接子元素也可见
                    Array.from(reviewOverlay.children).forEach(child => {{
                        if (child.style) {{
                            child.style.display = '';
                            child.style.visibility = 'visible';
                            child.style.height = 'auto';
                        }}
                    }});
                }}
                
                // 8. 立即调用 renderVisualAuditV3 渲染结果（自动显示）
                console.log('🎨 开始调用 renderVisualAuditV3...');
                console.log('📦 传递给 renderVisualAuditV3 的最终数据:', finalData);
                
                // 修复同步问题：先进行存在性检查
                if (window.renderVisualAuditV3) {{
                    try {{
                        // 确保 review-overlay 显示并设置 z-index
                        if (reviewOverlay) {{
                            reviewOverlay.style.display = 'block';
                            reviewOverlay.style.visibility = 'visible';
                            reviewOverlay.style.zIndex = '1000';
                            reviewOverlay.style.minHeight = '500px';
                        }}
                        
                        // 强制渲染触发：显式调用渲染函数（传递完整的 responseData，包含 structured 字段）
                        // renderVisualAuditV3 内部已经处理了防递归逻辑和数据脱壳
                        window.renderVisualAuditV3(responseData);
                        console.log('✅ renderVisualAuditV3 调用成功');
                        
                        // 渲染后再次确保显示状态和滚动
                        setTimeout(() => {{
                            if (reviewOverlay) {{
                                reviewOverlay.style.display = 'block';
                                reviewOverlay.style.visibility = 'visible';
                                reviewOverlay.style.height = 'auto';
                                reviewOverlay.style.zIndex = '1000';
                                reviewOverlay.style.minHeight = '500px';
                                
                                // 平滑滚动到评审区域
                                reviewOverlay.scrollIntoView({{ 
                                    behavior: 'smooth', 
                                    block: 'start' 
                                }});
                            }}
                            console.log('✅ 渲染完成，review-overlay 已显示并滚动到位');
                        }}, 300);
                    }} catch (renderError) {{
                        console.error('❌ 渲染过程出错:', renderError);
                        if (reviewOverlay) {{
                            const reviewContainer = document.getElementById('review-container');
                            if (reviewContainer) {{
                                reviewContainer.innerHTML = `
                                    <div style="text-align: center; padding: 60px 20px; color: #dc2626;">
                                        <h2>⚠️ 渲染失败</h2>
                                        <p>${{renderError.message}}</p>
                                        <p style="font-size: 12px; color: #64748b; margin-top: 10px;">请检查控制台获取详细信息</p>
                                    </div>
                                `;
                                reviewContainer.style.display = 'block';
                            }}
                        }}
                    }}
                }} else {{
                    console.error('渲染脚本尚未加载');
                    const errorMsg = '渲染脚本尚未加载，请确保 visual_audit_v3.js 已正确引入';
                    console.error('❌', errorMsg);
                    
                    if (reviewOverlay) {{
                        reviewOverlay.style.display = 'block';
                        reviewOverlay.style.visibility = 'visible';
                        reviewOverlay.style.zIndex = '1000';
                        reviewOverlay.style.minHeight = '500px';
                        
                        const reviewContainer = document.getElementById('review-container');
                        if (reviewContainer) {{
                            reviewContainer.style.display = 'block';
                            reviewContainer.innerHTML = `
                                <div style="text-align: center; padding: 60px 20px; color: #dc2626; background: #fef2f2; border-radius: 12px; border: 2px solid #dc2626;">
                                    <div style="font-size: 48px; margin-bottom: 20px;">⚠️</div>
                                    <h2 style="margin: 0 0 16px 0; color: #dc2626;">渲染脚本未加载</h2>
                                    <p style="margin: 0 0 12px 0; color: #991b1b; font-size: 14px;">${{errorMsg}}</p>
                                    <p style="margin: 0 0 24px 0; color: #64748b; font-size: 12px;">请检查 visual_audit_v3.js 是否正确引入</p>
                                    <button onclick="location.reload()" style="padding: 12px 24px; background: #dc2626; color: white; border: none; border-radius: 8px; cursor: pointer; font-weight: 600;">
                                        刷新页面重试
                                    </button>
                                </div>
                            `;
                        }} else {{
                            reviewOverlay.innerHTML = `
                                <div style="text-align: center; padding: 60px 20px; color: #dc2626; background: #fef2f2; border-radius: 12px; border: 2px solid #dc2626;">
                                    <div style="font-size: 48px; margin-bottom: 20px;">⚠️</div>
                                    <h2 style="margin: 0 0 16px 0; color: #dc2626;">渲染脚本未加载</h2>
                                    <p style="margin: 0 0 12px 0; color: #991b1b; font-size: 14px;">${{errorMsg}}</p>
                                    <p style="margin: 0 0 24px 0; color: #64748b; font-size: 12px;">请检查 visual_audit_v3.js 是否正确引入</p>
                                    <button onclick="location.reload()" style="padding: 12px 24px; background: #dc2626; color: white; border: none; border-radius: 8px; cursor: pointer; font-weight: 600;">
                                        刷新页面重试
                                    </button>
                                </div>
                            `;
                        }}
                        
                        // 滚动到错误信息区域
                        setTimeout(() => {{
                            reviewOverlay.scrollIntoView({{ 
                                behavior: 'smooth', 
                                block: 'start' 
                            }});
                        }}, 100);
                    }}
                }}
            }} catch (error) {{
                console.error('❌ 评审请求失败:', error);
                console.error('错误详情:', {{
                    name: error.name,
                    message: error.message,
                    stack: error.stack
                }});
                
                // 异常反馈：在 review-overlay 区域显示错误信息
                if (reviewOverlay) {{
                    reviewOverlay.style.display = 'block';
                    reviewOverlay.style.visibility = 'visible';
                    reviewOverlay.style.zIndex = '1000';
                    reviewOverlay.style.minHeight = '500px';
                    
                    // 清空容器并显示错误信息
                    const containersToClear = [
                        'overall-grade',
                        'overall-score-text',
                        'overall-summary',
                        'criteria-grid',
                        'action-list',
                        'paragraph-cards',
                        'model-essay-content',
                        'review-container'
                    ];
                    
                    containersToClear.forEach(id => {{
                        const el = document.getElementById(id);
                        if (el) el.innerHTML = '';
                    }});
                    
                    // 在 review-overlay 中显示错误信息
                    const reviewContainer = document.getElementById('review-container');
                    if (reviewContainer) {{
                        reviewContainer.style.display = 'block';
                        reviewContainer.style.visibility = 'visible';
                        reviewContainer.innerHTML = `
                            <div style="text-align: center; padding: 60px 20px; color: #dc2626; background: #fef2f2; border-radius: 12px; border: 2px solid #dc2626;">
                                <div style="font-size: 48px; margin-bottom: 20px;">⚠️</div>
                                <h2 style="margin: 0 0 16px 0; color: #dc2626;">评分获取失败，请重试</h2>
                                <p style="margin: 0 0 12px 0; color: #991b1b; font-size: 14px;">${{error.message}}</p>
                                <p style="margin: 0 0 24px 0; color: #64748b; font-size: 12px;">请检查网络连接或联系技术支持</p>
                                <button onclick="location.reload()" style="padding: 12px 24px; background: #dc2626; color: white; border: none; border-radius: 8px; cursor: pointer; font-weight: 600;">
                                    刷新页面重试
                                </button>
                            </div>
                        `;
                    }} else {{
                        // 如果 review-container 不存在，直接在 review-overlay 中显示
                        reviewOverlay.innerHTML = `
                            <div style="text-align: center; padding: 60px 20px; color: #dc2626; background: #fef2f2; border-radius: 12px; border: 2px solid #dc2626;">
                                <div style="font-size: 48px; margin-bottom: 20px;">⚠️</div>
                                <h2 style="margin: 0 0 16px 0; color: #dc2626;">评分获取失败，请重试</h2>
                                <p style="margin: 0 0 12px 0; color: #991b1b; font-size: 14px;">${{error.message}}</p>
                                <p style="margin: 0 0 24px 0; color: #64748b; font-size: 12px;">请检查网络连接或联系技术支持</p>
                                <button onclick="location.reload()" style="padding: 12px 24px; background: #dc2626; color: white; border: none; border-radius: 8px; cursor: pointer; font-weight: 600;">
                                    刷新页面重试
                                </button>
                            </div>
                        `;
                    }}
                    
                    // 滚动到错误信息区域
                    setTimeout(() => {{
                        reviewOverlay.scrollIntoView({{ 
                            behavior: 'smooth', 
                            block: 'start' 
                        }});
                    }}, 100);
                }}
                
                // 显示用户友好的错误提示
                let errorMessage = '后端连接失败，请检查服务器是否开启';
                if (error.message.includes('Failed to fetch') || error.message.includes('NetworkError')) {{
                    errorMessage = '后端连接失败，请检查服务器是否开启（localhost:3000）';
                }} else if (error.message.includes('HTTP error')) {{
                    errorMessage = `服务器错误: ${{error.message}}`;
                }} else {{
                    errorMessage = `请求失败: ${{error.message}}`;
                }}
                
                alert(errorMessage);
            }}
        }}

        // --- 7. 底部批改：整篇 Essay 级别（同屏对照修改） ---
        let isResubmit = false;
        let previousReview = "";
        
        async function submitReview(isResubmitFlag = false) {{
            isResubmit = isResubmitFlag;
            const btn = document.getElementById('ai-btn');
            const feedbackView = document.getElementById('feedback-view');
            const editableArea = document.getElementById('feedback-essay-editable');
            const contentDiv = document.getElementById('ai-content');
            const resubmitBtn = document.getElementById('resubmit-btn');
            const essay_question = getCurrentQuestion();
            const constraint = getLanguageConstraint();
            const essay_full = buildEssayText();
            const structure = getStructureSummary();

            const data = {{ 
                essay_question,
                essay_full,
                structure,
                language: currentLanguageMode,
                constraint,
                is_resubmit: isResubmit,
                previous_review: previousReview
            }};
            
            // 隐藏编辑区，显示批改视图
            document.getElementById('essay-constructor').style.display = 'none';
            document.getElementById('module-toolbar').style.display = 'none';
            document.querySelector('.review-actions').style.display = 'none';
            feedbackView.style.display = 'block';
            
            // 左侧显示可编辑的模块（PEEL 格子模式）
            renderEditableModules(editableArea);
            
            btn.innerText = "⌛ Teacher is grading..."; btn.disabled = true;
            contentDiv.innerText = "AI is analyzing your essay...";
            if (resubmitBtn) resubmitBtn.style.display = 'none';

            try {{
                const response = await fetch('/api/review', {{ 
                    method: 'POST', 
                    headers: {{ 'Content-Type': 'application/json' }}, 
                    body: JSON.stringify(data) 
                }});
                const result = await response.json();
                
                // 尝试解析 JSON 格式的响应
                let jsonData = null;
                if (result.structured) {{
                    // 如果 API 返回了结构化数据，直接使用
                    jsonData = result.structured;
                    console.log('✅ 收到结构化 JSON 响应:', jsonData);
                }} else if (result.review) {{
                    // 尝试从 review 文本中解析 JSON
                    try {{
                        let reviewText = result.review.trim();
                        // 移除可能的 markdown 代码块标记
                        if (reviewText.startsWith('```')) {{
                            const lines = reviewText.split('\\n');
                            lines.shift(); // 移除第一行
                            lines.pop(); // 移除最后一行
                            reviewText = lines.join('\\n');
                        }}
                        jsonData = JSON.parse(reviewText);
                        console.log('✅ 从文本中解析出 JSON:', jsonData);
                    }} catch (parseError) {{
                        console.warn('⚠️ JSON 解析失败:', parseError);
                        // 如果解析失败，显示友好错误提示（禁止显示原始 JSON）
                        const errorMsg = '<div class="card" style="background:#fef2f2; border-color:#dc2626; color:#991b1b; padding:24px; text-align:center;"><h3 style="margin:0 0 12px 0;">⚠️ 评审响应解析失败</h3><p style="margin:0; line-height:1.6;">AI 返回的数据格式异常，无法正确解析。请刷新页面重试，或联系技术支持。</p></div>';
                        const reviewContainer = document.getElementById('review-container');
                        if (reviewContainer) {{
                            reviewContainer.innerHTML = errorMsg;
                            const reviewOverlay = document.getElementById('review-overlay');
                            if (reviewOverlay) reviewOverlay.style.display = 'block';
                        }} else {{
                            contentDiv.innerHTML = errorMsg;
                        }}
                        saveReviewToLocal({{ error: 'parse_failed', examType: examType }});
                        if (resubmitBtn) resubmitBtn.style.display = 'block';
                        return;
                    }}
                }}
                
                // 如果有 JSON 数据，使用新的可视化界面
                if (jsonData) {{
                    // 检查是否为 V3.1 格式（包含 overall, criteria, paragraphs, actions, model_essay）
                    if (jsonData.overall && (jsonData.criteria || jsonData.dimension_scores) && Array.isArray(jsonData.paragraphs || [])) {{
                        // 转换 criteria 格式（如果是对象，转换为数组）
                        if (jsonData.criteria && !Array.isArray(jsonData.criteria)) {{
                            const criteriaObj = jsonData.criteria;
                            jsonData.criteria = Object.keys(criteriaObj).map(key => {{
                                const aoMatch = key.match(/AO\\d+/);
                                const ao = aoMatch ? aoMatch[0] : key;
                                return {{ ao, score: criteriaObj[key] }};
                            }});
                        }}
                        // 使用 Visual Audit V3.1 卡片系统
                        renderReview(jsonData, contentDiv);
                        saveReviewToLocal({{ structured: jsonData, examType: examType, timestamp: Date.now() }});
                    }} else if (jsonData.overall && jsonData.dimension_scores && jsonData.justification) {{
                        // 使用 Visual Audit V2.0 界面（向后兼容）
                        renderReview(jsonData, contentDiv);
                        saveReviewToLocal({{ structured: jsonData, examType: examType, timestamp: Date.now() }});
                    }} else {{
                        // JSON 结构不完整，显示友好错误提示
                        console.warn('⚠️ JSON 结构不完整，无法渲染卡片视图');
                        const errorMsg = '<div class="card" style="background:#fef2f2; border-color:#dc2626; color:#991b1b; padding:24px; text-align:center;"><h3 style="margin:0 0 12px 0;">⚠️ 评审数据格式异常</h3><p style="margin:0; line-height:1.6;">AI 返回的数据格式不符合预期。请刷新页面重试，或联系技术支持。</p></div>';
                        const reviewContainer = document.getElementById('review-container');
                        if (reviewContainer) {{
                            reviewContainer.innerHTML = errorMsg;
                            const reviewOverlay = document.getElementById('review-overlay');
                            if (reviewOverlay) reviewOverlay.style.display = 'block';
                        }} else {{
                            contentDiv.innerHTML = errorMsg;
                        }}
                        saveReviewToLocal({{ error: 'incomplete_json', examType: examType }});
                    }}
                }} else {{
                    // 无法解析 JSON，显示友好错误提示
                    console.warn('⚠️ 无法解析评审响应');
                    const errorMsg = '<div class="card" style="background:#fef2f2; border-color:#dc2626; color:#991b1b; padding:24px; text-align:center;"><h3 style="margin:0 0 12px 0;">⚠️ 评审响应解析失败</h3><p style="margin:0; line-height:1.6;">AI 返回的数据无法正确解析。请刷新页面重试，或联系技术支持。</p></div>';
                    const reviewContainer = document.getElementById('review-container');
                    if (reviewContainer) {{
                        reviewContainer.innerHTML = errorMsg;
                        const reviewOverlay = document.getElementById('review-overlay');
                        if (reviewOverlay) reviewOverlay.style.display = 'block';
                    }} else {{
                        contentDiv.innerHTML = errorMsg;
                    }}
                    saveReviewToLocal({{ error: 'parse_failed', examType: examType }});
                }}
                
                if (resubmitBtn) resubmitBtn.style.display = 'block';
            }} catch (e) {{
                console.error('❌ API 请求失败:', e);
                contentDiv.innerHTML = '<div style="color:#e63946; padding:20px;">⚠️ Connection failed. Please check your network and try again.</div>';
            }}
            finally {{ 
                btn.innerText = "🚀 SUBMIT FOR AI TEACHER'S REVIEW"; 
                btn.disabled = false;
                feedbackView.scrollIntoView({{ behavior: 'smooth' }});
            }}
        }}

        // 渲染可编辑模块（在 Review 页面左侧）
        function renderEditableModules(container) {{
            if (!container) return;
            let bodyIndex = 0;
            let introIndex = 0;
            let conclusionIndex = 0;
            const html = modules.map((m) => {{
                const cfg = getBoxConfig(m.type);
                let label = "";
                let blockId = "";
                if (m.type === 'intro') {{
                    introIndex += 1;
                    label = "Intro";
                    blockId = `intro-${{introIndex}}`;
                }} else if (m.type === 'conclusion') {{
                    conclusionIndex += 1;
                    label = "Conclusion";
                    blockId = `conclusion-${{conclusionIndex}}`;
                }} else {{
                    bodyIndex += 1;
                    label = "Body Paragraph " + bodyIndex;
                    blockId = `body-${{bodyIndex}}`;
                }}
                
                if (m.mode === 'free') {{
                    const freeText = (m.freeText || "").trim();
                    return `
                        <div class="essay-module" data-id="${{m.id}}" data-type="${{m.type}}" data-block-id="${{blockId}}">
                            <div class="module-header">
                                <span class="module-tag">${{label}}</span>
                            </div>
                            <div class="editor-box">
                                <textarea 
                                    data-module="${{m.id}}"
                                    data-free="1"
                                    style="width:100%; min-height:120px; padding:12px; border:1.5px solid #ced4da; border-radius:8px; font-size:14px; line-height:1.5;"
                                    oninput="onFreeInput('${{m.id}}', this.value)"
                                >${{freeText}}</textarea>
                            </div>
                        </div>
                    `;
                }} else {{
                    const boxesHtml = cfg.map((boxCfg, idx) => {{
                        const value = (m.boxes && typeof m.boxes[idx] === 'string') ? m.boxes[idx] : "";
                        return `
                            <div class="editor-box">
                                <div class="label">${{boxCfg.label}}</div>
                                <textarea 
                                    data-module="${{m.id}}" 
                                    data-box="${{idx}}" 
                                    style="width:100%; height:95px; padding:12px; border:1.5px solid #ced4da; border-radius:8px; font-size:14px; line-height:1.5;"
                                    oninput="onBoxInput('${{m.id}}', ${{idx}}, this.value)"
                                >${{value}}</textarea>
                            </div>
                        `;
                    }}).join("");
                    return `
                        <div class="essay-module" data-id="${{m.id}}" data-type="${{m.type}}" data-block-id="${{blockId}}">
                            <div class="module-header">
                                <span class="module-tag">${{label}}</span>
                            </div>
                            ${{boxesHtml}}
                        </div>
                    `;
                }}
            }}).join("");
            container.innerHTML = html;
        }}

        // 切换编辑视图模式（PEEL 格子 / 纯文本）
        let editViewMode = 'peel'; // 'peel' or 'text'
        function toggleEditViewMode() {{
            const container = document.getElementById('feedback-essay-editable');
            const toggleBtn = document.getElementById('view-mode-toggle');
            if (!container) return;
            
            editViewMode = editViewMode === 'peel' ? 'text' : 'peel';
            
            if (editViewMode === 'text') {{
                // 切换到纯文本模式
                const essayText = buildEssayText();
                container.innerHTML = `
                    <textarea 
                        id="essay-text-editor"
                        style="width:100%; min-height:400px; padding:20px; border:1.5px solid #ced4da; border-radius:8px; font-size:14px; line-height:1.8; font-family:inherit;"
                        oninput="onTextEditorInput(this.value)"
                    >${{essayText}}</textarea>
                `;
                if (toggleBtn) toggleBtn.innerText = 'Switch to PEEL Mode';
            }} else {{
                // 切换回 PEEL 格子模式
                renderEditableModules(container);
                if (toggleBtn) toggleBtn.innerText = 'Switch to Text Mode';
            }}
        }}

        function onTextEditorInput(value) {{
            // 纯文本模式下的输入同步到 modules（简单实现：按段落拆分）
            const paragraphs = value.split('\\n\\n').map(p => p.trim()).filter(p => p.length > 0);
            // 这里可以更智能地匹配到现有模块，暂时简单处理
            scheduleSave();
        }}

        // Visual Audit V2.0: 渲染双栏对比视图
        function renderReviewOverlay(structuredData, originalText) {{
            if (!structuredData || !originalText) return;
            
            // 隐藏写作区和传统反馈视图
            const essayConstructor = document.getElementById('essay-constructor');
            const moduleToolbar = document.getElementById('module-toolbar');
            const reviewActions = document.querySelector('.review-actions');
            const feedbackView = document.getElementById('feedback-view');
            
            if (essayConstructor) essayConstructor.style.display = 'none';
            if (moduleToolbar) moduleToolbar.style.display = 'none';
            if (reviewActions) reviewActions.style.display = 'none';
            if (feedbackView) feedbackView.style.display = 'none';
            
            // 显示双栏对比视图
            const reviewOverlay = document.getElementById('review-overlay');
            if (reviewOverlay) {{
                reviewOverlay.style.display = 'block';
            }}
            
            // 渲染左栏：原文高亮
            const feedbackLoops = structuredData.feedback_loops || [];
            // 保存 feedbackLoops 到全局，供 scrollToOriginalText 使用
            window.currentFeedbackLoops = feedbackLoops;
            renderOriginalTextWithHighlights(originalText, feedbackLoops);
            
            // 渲染右栏：分数和诊断卡片
            renderDiagnosticsPanel(structuredData);
            
            // 显示重新提交按钮
            const resubmitBtn = document.getElementById('review-resubmit-btn');
            if (resubmitBtn) resubmitBtn.style.display = 'block';
        }}
        
        // 渲染左栏：原文高亮（增强版，支持错误标记）
        function renderOriginalTextWithHighlights(originalText, feedbackLoops) {{
            const container = document.getElementById('review-original-text');
            if (!container || !originalText) {{
                if (container) container.innerHTML = '<p style="color:#64748b;">暂无原文内容</p>';
                return;
            }}
            
            // 转义 HTML 防止 XSS
            const escapeHtml = (text) => {{
                const div = document.createElement('div');
                div.textContent = text;
                return div.innerHTML;
            }};
            
            if (!Array.isArray(feedbackLoops) || feedbackLoops.length === 0) {{
                // 如果没有反馈循环，直接显示原文（转义 HTML）
                container.innerHTML = escapeHtml(originalText).replace(/\\n/g, '<br>');
                return;
            }}
            
            // 为每个 feedback_loop 创建高亮标记
            // 按位置排序，从后往前替换，避免位置偏移
            const segments = feedbackLoops
                .map((loop, index) => ({{
                    index: index,
                    segment: loop.original_segment || loop.before || '',
                    position: originalText.indexOf(loop.original_segment || loop.before || ''),
                    isError: loop.diagnosis && (loop.diagnosis.toLowerCase().includes('error') || 
                                               loop.diagnosis.toLowerCase().includes('wrong') ||
                                               loop.diagnosis.toLowerCase().includes('incorrect'))
                }}))
                .filter(item => item.segment && item.position !== -1)
                .sort((a, b) => b.position - a.position); // 从后往前排序
            
            let highlightedText = escapeHtml(originalText);
            
            // 从后往前替换，避免位置偏移
            segments.forEach(({ index, segment, isError }) => {{
                const escapedSegment = escapeHtml(segment);
                const errorClass = isError ? 'error-mark' : '';
                const highlightHtml = `<mark class="${{errorClass}}" data-feedback-index="${{index}}" onclick="scrollToDiagnostic(${{index}})" style="cursor:pointer;">${{escapedSegment}}</mark>`;
                
                // 查找最后一个匹配位置
                const lastIndex = highlightedText.lastIndexOf(escapedSegment);
                if (lastIndex !== -1) {{
                    highlightedText = highlightedText.substring(0, lastIndex) + 
                                    highlightHtml + 
                                    highlightedText.substring(lastIndex + escapedSegment.length);
                }}
            }});
            
            // 处理换行
            highlightedText = highlightedText.replace(/\\n/g, '<br>');
            
            container.innerHTML = highlightedText;
        }}
        
        // 获取维度标签映射（根据考试类型）
        function getDimensionLabel(dimensionName, examType) {{
            const examTypeUpper = (examType || currentExamType || 'AL_ECON').toUpperCase();
            
            // IELTS 维度映射
            if (examTypeUpper === 'IELTS') {{
                const ieltsMap = {{
                    'Task Response': 'TR',
                    'Coherence & Cohesion': 'CC',
                    'Lexical Resource': 'LR',
                    'Grammatical Range & Accuracy': 'GRA'
                }};
                return ieltsMap[dimensionName] || dimensionName.substring(0, 4).toUpperCase();
            }}
            
            // A-Level 维度映射
            if (examTypeUpper === 'AL_ECON' || examTypeUpper === 'ALEVEL' || examTypeUpper === 'A-LEVEL') {{
                const alevelMap = {{
                    'AO1 Knowledge': 'AO1',
                    'AO2 Application': 'AO2',
                    'AO3 Analysis': 'AO3',
                    'AO4 Evaluation': 'AO4'
                }};
                return alevelMap[dimensionName] || dimensionName.substring(0, 4).toUpperCase();
            }}
            
            // 默认：取前4个字符
            return dimensionName.substring(0, 4).toUpperCase();
        }}
        
        // 计算分数百分比（用于进度条）
        function calculateScorePercentage(score, examType) {{
            const examTypeUpper = (examType || currentExamType || 'AL_ECON').toUpperCase();
            
            // IELTS: 0-9 分制
            if (examTypeUpper === 'IELTS') {{
                const numScore = parseFloat(score);
                if (isNaN(numScore)) return 0;
                return Math.min(100, Math.max(0, (numScore / 9) * 100));
            }}
            
            // A-Level: A*-E 等级制，转换为百分比
            if (examTypeUpper === 'AL_ECON' || examTypeUpper === 'ALEVEL' || examTypeUpper === 'A-LEVEL') {{
                const gradeMap = {{
                    'A*': 95,
                    'A': 85,
                    'B': 75,
                    'C': 65,
                    'D': 55,
                    'E': 45
                }};
                const grade = String(score).toUpperCase();
                return gradeMap[grade] || 50;
            }}
            
            return 50; // 默认值
        }}
        
        // 渲染右栏：分数和诊断卡片
        function renderDiagnosticsPanel(structuredData) {{
            // 获取当前考试类型
            const examSelector = document.getElementById('exam-type-selector');
            const examType = examSelector ? examSelector.value : currentExamType;
            
            // 渲染总分
            const overallScoreEl = document.getElementById('review-overall-score');
            if (overallScoreEl) {{
                overallScoreEl.textContent = structuredData.overall || '-';
            }}
            
            // 渲染维度得分（带进度条）
            const dimensionScoresEl = document.getElementById('review-dimension-scores');
            if (dimensionScoresEl && structuredData.dimension_scores) {{
                const dimensions = Object.keys(structuredData.dimension_scores);
                if (dimensions.length > 0) {{
                    const scoresHtml = dimensions.map(dim => {{
                        const score = structuredData.dimension_scores[dim];
                        const dimLabel = getDimensionLabel(dim, examType);
                        const percentage = calculateScorePercentage(score, examType);
                        
                        return `
                            <div class="dimension-score-item">
                                <div class="dimension-score-label">${{dimLabel}}</div>
                                <div class="dimension-progress-bar">
                                    <div class="dimension-progress-fill" style="width: ${{percentage}}%">
                                        <span class="dimension-progress-label">${{Math.round(percentage)}}%</span>
                                    </div>
                                </div>
                            </div>
                        `;
                    }}).join('');
                    dimensionScoresEl.innerHTML = scoresHtml;
                }} else {{
                    dimensionScoresEl.innerHTML = '<p style="color:#64748b; font-size:12px; text-align:center;">暂无维度得分</p>';
                }}
            }}
            
            // 渲染诊断卡片流
            const diagnosticsEl = document.getElementById('review-diagnostics');
            if (diagnosticsEl) {{
                const feedbackLoops = structuredData.feedback_loops || [];
                if (Array.isArray(feedbackLoops) && feedbackLoops.length > 0) {{
                    const cardsHtml = feedbackLoops.map((loop, index) => {{
                        const diagnosis = loop.diagnosis || loop.feedback || loop.justification || '暂无诊断信息';
                        const before = loop.before || loop.original_segment || '';
                        const after = loop.after || loop.improved || loop.suggested || '';
                        
                        // 转义 HTML 防止 XSS
                        const escapeHtml = (text) => {{
                            const div = document.createElement('div');
                            div.textContent = text;
                            return div.innerHTML;
                        }};
                        
                        return `
                            <div class="diagnostic-card" id="diagnostic-card-${{index}}" data-feedback-index="${{index}}" onclick="scrollToOriginalText(${{index}})" style="cursor:pointer;">
                                <div class="diagnostic-text">${{escapeHtml(diagnosis)}}</div>
                                ${{before || after ? `
                                <div class="comparison-box">
                                    ${{before ? `
                                    <div class="comparison-before">
                                        <div class="comparison-label">🔴 Before</div>
                                        <div class="comparison-text">${{escapeHtml(before)}}</div>
                                    </div>
                                    ` : '<div></div>'}}
                                    ${{after ? `
                                    <div class="comparison-after">
                                        <div class="comparison-label">🟢 After</div>
                                        <div class="comparison-text">${{escapeHtml(after)}}</div>
                                    </div>
                                    ` : '<div></div>'}}
                                </div>
                                ` : ''}}
                            </div>
                        `;
                    }}).join('');
                    diagnosticsEl.innerHTML = cardsHtml;
                }} else {{
                    diagnosticsEl.innerHTML = '<p style="color:#6c757d; text-align:center; padding:20px;">暂无诊断信息</p>';
                }}
            }}
        }}
        
        // 点击高亮句子时，滚动到对应的诊断卡片
        function scrollToDiagnostic(feedbackIndex) {{
            // 移除所有高亮的 active 状态
            document.querySelectorAll('mark[data-feedback-index]').forEach(mark => {{
                mark.classList.remove('active');
            }});
            document.querySelectorAll('.diagnostic-card').forEach(card => {{
                card.classList.remove('active');
            }});
            
            // 高亮对应的句子
            const markEl = document.querySelector(`mark[data-feedback-index="${{feedbackIndex}}"]`);
            if (markEl) {{
                markEl.classList.add('active');
                // 平滑滚动到高亮句子
                markEl.scrollIntoView({{ behavior: 'smooth', block: 'center' }});
            }}
            
            // 高亮并滚动到对应的诊断卡片
            const cardEl = document.getElementById(`diagnostic-card-${{feedbackIndex}}`);
            if (cardEl) {{
                cardEl.classList.add('active');
                // 平滑滚动到诊断卡片
                cardEl.scrollIntoView({{ behavior: 'smooth', block: 'nearest' }});
            }}
        }}
        
        // 点击诊断卡片时，滚动到左侧原文对应段落（反向联动）
        function scrollToOriginalText(feedbackIndex) {{
            // 移除所有高亮的 active 状态
            document.querySelectorAll('mark[data-feedback-index]').forEach(mark => {{
                mark.classList.remove('active');
            }});
            document.querySelectorAll('.diagnostic-card').forEach(card => {{
                card.classList.remove('active');
            }});
            
            // 激活对应的诊断卡片
            const cardEl = document.getElementById(`diagnostic-card-${{feedbackIndex}}`);
            if (cardEl) {{
                cardEl.classList.add('active');
            }}
            
            // 高亮并滚动到左侧原文对应的句子（呼吸灯效果）
            const markEl = document.querySelector(`mark[data-feedback-index="${{feedbackIndex}}"]`);
            if (markEl) {{
                markEl.classList.add('active');
                // 平滑滚动到高亮句子，并居中显示
                markEl.scrollIntoView({{ behavior: 'smooth', block: 'center' }});
                
                // 3秒后移除高亮（呼吸灯效果会自动停止）
                setTimeout(() => {{
                    markEl.classList.remove('active');
                }}, 3000);
            }} else {{
                // 如果找不到对应的 mark，尝试查找对应的模块
                const feedbackLoops = window.currentFeedbackLoops || [];
                if (feedbackLoops[feedbackIndex]) {{
                    const loop = feedbackLoops[feedbackIndex];
                    const blockId = loop.block_id || '';
                    if (blockId) {{
                        locateIssue(blockId);
                    }}
                }}
            }}
        }}
        
        // 关闭双栏对比视图
        function closeReviewOverlay() {{
            const reviewOverlay = document.getElementById('review-overlay');
            if (reviewOverlay) {{
                reviewOverlay.style.display = 'none';
            }}
            // 恢复写作区
            document.getElementById('essay-constructor').style.display = 'block';
            document.getElementById('module-toolbar').style.display = 'flex';
            const actions = document.querySelector('.review-actions');
            if (actions) actions.style.display = 'flex';
        }}
        
        // 保存评审结果到 localStorage
        function saveReviewToLocal(reviewData) {{
            try {{
                localStorage.setItem(REVIEW_STORAGE_KEY, JSON.stringify(reviewData));
            }} catch (e) {{
                console.warn('保存评审结果失败:', e);
            }}
        }}
        
        // 从 localStorage 加载评审结果
        function loadReviewFromLocal() {{
            try {{
                const raw = localStorage.getItem(REVIEW_STORAGE_KEY);
                if (!raw) return null;
                return JSON.parse(raw);
            }} catch (e) {{
                console.warn('加载评审结果失败:', e);
                return null;
            }}
        }}

        // 关闭评审覆盖层
        function closeReviewOverlay() {{
            const reviewOverlay = document.getElementById('review-overlay');
            if (reviewOverlay) {{
                reviewOverlay.style.display = 'none';
            }}
            // 显示编辑区
            const essayConstructor = document.getElementById('essay-constructor');
            const moduleToolbar = document.getElementById('module-toolbar');
            const reviewActions = document.querySelector('.review-actions');
            if (essayConstructor) essayConstructor.style.display = 'block';
            if (moduleToolbar) moduleToolbar.style.display = 'flex';
            if (reviewActions) reviewActions.style.display = 'flex';
        }}
        
        // Visual Audit V3.1: 渲染结构化 JSON 评审结果
        function renderReview(jsonData, container) {{
            if (!jsonData) return;
            
            // 检测数据格式：如果是新的 V3.1 格式（包含 overall, criteria, paragraphs, actions, model_essay）
            if (jsonData.overall && jsonData.criteria && Array.isArray(jsonData.paragraphs)) {{
                renderReviewV31(jsonData);
            }} else {{
                // 向后兼容：使用旧的 V2.0 格式
                if (!container) return;
                const essayFull = buildEssayText();
                let feedbackLoops = jsonData.feedback_loops || [];
                if (feedbackLoops.length === 0 && jsonData.justification) {{
                    const justification = jsonData.justification || "";
                    const blockIdPattern = /\\[block_id:\\s*([a-z]+-\\d+)\\]/gi;
                    const paragraphs = justification.split('\\n\\n').filter(p => p.trim());
                    paragraphs.forEach((para, index) => {{
                        const blockIdMatches = [...para.matchAll(blockIdPattern)];
                        const blockIds = [...new Set(blockIdMatches.map(m => m[1]))];
                        const displayText = para.replace(/\\[block_id:[^\\]]+\\]/gi, '').trim();
                        if (displayText && blockIds.length > 0) {{
                            feedbackLoops.push({{
                                diagnosis: displayText,
                                original_segment: '',
                                improved: ''
                            }});
                        }}
                    }});
                }}
                renderReviewOverlay({{
                    overall: jsonData.overall || '-',
                    dimension_scores: jsonData.dimension_scores || {{}},
                    feedback_loops: feedbackLoops,
                    justification: jsonData.justification || ''
                }}, essayFull);
            }}
        }}
        
        // Visual Audit V3.1: 结构化卡片系统渲染
        function renderReviewV31(data) {{
            const container = document.getElementById('review-container');
            if (!container) return;
            
            // 隐藏其他视图
            const essayConstructor = document.getElementById('essay-constructor');
            const moduleToolbar = document.getElementById('module-toolbar');
            const reviewActions = document.querySelector('.review-actions');
            const feedbackView = document.getElementById('feedback-view');
            
            if (essayConstructor) essayConstructor.style.display = 'none';
            if (moduleToolbar) moduleToolbar.style.display = 'none';
            if (reviewActions) reviewActions.style.display = 'none';
            if (feedbackView) feedbackView.style.display = 'none';
            
            // 显示 review-overlay
            const reviewOverlay = document.getElementById('review-overlay');
            if (reviewOverlay) reviewOverlay.style.display = 'block';
            
            // 清空容器并渲染所有卡片
            container.innerHTML = '';
            
            // 1. [总分卡片] Score Card
            container.innerHTML += renderScoreCard(data.overall);
            
            // 2. [评分维度卡片] Criteria Card
            container.innerHTML += renderCriteriaCard(data.criteria);
            
            // 3. [修改任务卡片] Actions Card
            container.innerHTML += renderActionsCard(data.actions);
            
            // 4. [段落诊断区域] Paragraphs Area
            container.innerHTML += renderParagraphsArea(data.paragraphs);
            
            // 5. [范文卡片] Model Essay Card
            container.innerHTML += renderModelEssayCard(data.model_essay);
        }}
        
        // [总分卡片] Score Card
        function renderScoreCard(overall) {{
            if (!overall) return '';
            const score = overall.score || '-';
            const grade = overall.grade || '-';
            const summary = overall.summary || '暂无全局诊断结论';
            
            return `
                <div id="score-card" class="card">
                    <div class="score-circle">${{score}}</div>
                    <div class="score-grade">${{grade}}</div>
                    <div class="score-summary">${{escapeHtml(summary)}}</div>
                </div>
            `;
        }}
        
        // [评分维度卡片] Criteria Card
        function renderCriteriaCard(criteria) {{
            if (!criteria) return '';
            
            // 支持数组格式：[{ao: 'AO1', score: 85}]
            // 也支持对象格式：{AO1_Knowledge: 85, AO2_Application: 70}
            let criteriaArray = [];
            
            if (Array.isArray(criteria)) {{
                criteriaArray = criteria;
            }} else if (typeof criteria === 'object') {{
                // 转换对象为数组
                criteriaArray = Object.keys(criteria).map(key => {{
                    const aoMatch = key.match(/AO\\d+/);
                    const ao = aoMatch ? aoMatch[0] : key.replace(/_.*$/, '');
                    return {{ ao, score: criteria[key] }};
                }});
            }} else {{
                return '';
            }}
            
            const criteriaMap = {{
                'AO1': 'AO1: Knowledge',
                'AO2': 'AO2: Application',
                'AO3': 'AO3: Analysis',
                'AO4': 'AO4: Evaluation'
            }};
            
            const itemsHtml = criteriaArray.map(criterion => {{
                const aoKey = criterion.ao || '';
                const label = criteriaMap[aoKey] || aoKey;
                const score = criterion.score || 0;
                const percentage = calculateCriteriaPercentageV31(score);
                
                return `
                    <div class="criterion-item">
                        <div class="criterion-label">${{label}}</div>
                        <div class="criterion-progress-bar">
                            <div class="criterion-progress-fill" style="width: ${{percentage}}%"></div>
                        </div>
                    </div>
                `;
            }}).join('');
            
            return `
                <div id="criteria-card" class="card">
                    <h3 class="card-title">评分维度</h3>
                    <div class="criteria-grid">${{itemsHtml}}</div>
                </div>
            `;
        }}
        
        // 计算 Criteria 百分比
        function calculateCriteriaPercentageV31(score) {{
            if (typeof score === 'number') {{
                return Math.min(100, Math.max(0, score));
            }}
            const gradeMap = {{ 'A*': 95, 'A': 85, 'B': 75, 'C': 65, 'D': 55, 'E': 45 }};
            return gradeMap[score] || 50;
        }}
        
        // [修改任务卡片] Actions Card
        function renderActionsCard(actions) {{
            if (!actions || !Array.isArray(actions)) return '';
            
            const itemsHtml = actions.map((action, index) => {{
                const text = action.text || action || '';
                return `
                    <div class="action-item" id="action-item-${{index}}">
                        <input 
                            type="checkbox" 
                            class="action-checkbox" 
                            id="action-checkbox-${{index}}"
                            onchange="toggleActionV31(${{index}})"
                        >
                        <label for="action-checkbox-${{index}}" class="action-text">${{escapeHtml(text)}}</label>
                    </div>
                `;
            }}).join('');
            
            return `
                <div id="actions-card" class="card">
                    <h3 class="card-title">修改任务清单</h3>
                    <div class="action-list">${{itemsHtml}}</div>
                </div>
            `;
        }}
        
        // 切换 Action 完成状态
        function toggleActionV31(index) {{
            const checkbox = document.getElementById(`action-checkbox-${{index}}`);
            const item = document.getElementById(`action-item-${{index}}`);
            if (checkbox && item) {{
                if (checkbox.checked) {{
                    item.classList.add('completed');
                }} else {{
                    item.classList.remove('completed');
                }}
            }}
        }}
        
        // [段落诊断区域] Paragraphs Area
        function renderParagraphsArea(paragraphs) {{
            if (!paragraphs || !Array.isArray(paragraphs)) return '';
            
            const cardsHtml = paragraphs.map((para, index) => {{
                const type = para.type || 'Body';
                const typeLabel = type.charAt(0).toUpperCase() + type.slice(1);
                const peelCheck = para.peel_check || {{}};
                const issues = para.issues || [];
                const exampleRevision = para.example_revision || '';
                
                // PEEL 状态灯
                const peelStatus = renderPeelStatusV31(peelCheck);
                
                // Issues 列表
                const issuesHtml = issues.map(issue => 
                    `<div class="issue-item">${{escapeHtml(issue)}}</div>`
                ).join('') || '<div class="issue-item" style="color:#64748b;">无问题</div>';
                
                return `
                    <div class="paragraph-card">
                        <div class="paragraph-header">
                            <span class="paragraph-type">${{typeLabel}}</span>
                            <div class="peel-status">${{peelStatus}}</div>
                        </div>
                        <div class="paragraph-surgery">
                            <div class="diagnosis-box">
                                <div class="diagnosis-label">Issues</div>
                                <div class="issue-list">${{issuesHtml}}</div>
                            </div>
                            <div class="revision-box">
                                <div class="revision-label">Example Revision</div>
                                <div class="revision-text">${{escapeHtml(exampleRevision) || '暂无修改建议'}}</div>
                            </div>
                        </div>
                    </div>
                `;
            }}).join('');
            
            return `
                <div id="paragraphs-area" class="card">
                    <h3 class="card-title">段落诊断</h3>
                    ${{cardsHtml}}
                </div>
            `;
        }}
        
        // 渲染 PEEL 状态灯
        function renderPeelStatusV31(peelCheck) {{
            const status = [
                peelCheck.point || false,
                peelCheck.evidence || false,
                peelCheck.explanation || false,
                peelCheck.link || false
            ];
            const labels = ['P', 'E', 'E', 'L'];
            
            return status.map((isValid, index) => {{
                const className = isValid ? 'dot-pass' : 'dot-fail';
                return `<span class="status-dot ${{className}}" title="${{labels[index]}}: ${{isValid ? 'Valid' : 'Missing'}}"></span>`;
            }}).join('') + '<span style="margin-left:8px; font-size:11px; color:#64748b;">PEEL</span>';
        }}
        
        // [范文卡片] Model Essay Card
        function renderModelEssayCard(modelEssay) {{
            if (!modelEssay) return '';
            
            return `
                <div id="model-essay-card" class="card">
                    <h3 class="card-title">Model Essay</h3>
                    <button class="model-essay-toggle" onclick="toggleModelEssayV31()">
                        📖 Show Full Model Essay
                    </button>
                    <div class="model-essay-content" id="model-essay-content">${{escapeHtml(modelEssay)}}</div>
                </div>
            `;
        }}
        
        // 切换范文显示/隐藏
        function toggleModelEssayV31() {{
            const btn = document.querySelector('.model-essay-toggle');
            const content = document.getElementById('model-essay-content');
            if (content && btn) {{
                if (content.classList.contains('show')) {{
                    content.classList.remove('show');
                    btn.textContent = '📖 Show Full Model Essay';
                }} else {{
                    content.classList.add('show');
                    btn.textContent = '📖 Hide Model Essay';
                }}
            }}
        }}
        
        // HTML 转义函数
        function escapeHtml(text) {{
            if (!text) return '';
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }}

        // 渲染 AI 反馈（已废弃：禁止直接显示原始文本/JSON）
        // 此函数已不再使用，所有渲染都通过 renderReview 使用卡片系统
        // 保留此函数仅用于向后兼容，但已禁用 JSON 渲染
        function renderAIFeedback(container, reviewText) {{
            if (!container || !reviewText) return;
            
            // 检测是否为 JSON 格式（禁止直接渲染）
            const trimmed = reviewText.trim();
            if ((trimmed.startsWith('{{') || trimmed.startsWith('[')) && trimmed.endsWith('}}') || trimmed.endsWith(']')) {{
                // 尝试解析 JSON，如果成功则使用卡片系统
                try {{
                    const jsonData = JSON.parse(trimmed);
                    renderReview(jsonData, container);
                    return;
                }} catch (e) {{
                    // JSON 解析失败，显示友好错误提示（禁止显示原始 JSON）
                    const errorMsg = '<div class="card" style="background:#fef2f2; border-color:#dc2626; color:#991b1b; padding:24px; text-align:center;"><h3 style="margin:0 0 12px 0;">⚠️ 数据格式异常</h3><p style="margin:0; line-height:1.6;">检测到 JSON 格式的数据，但无法正确解析。请刷新页面重试。</p></div>';
                    container.innerHTML = errorMsg;
                    return;
                }}
            }}
            
            // 仅处理非 JSON 的文本反馈（向后兼容）
            // 解析 AI 反馈，查找 block_id 标记
            const blockIdPattern = /\\[block_id:\\s*([a-z]+-\\d+)\\]/gi;
            const bodyPattern = /Body\\s+(?:Paragraph\\s+)?(\\d+)/gi;
            
            let html = '<div class="ai-feedback-card">';
            const paragraphs = reviewText.split('\\n\\n').filter(p => p.trim());
            
            paragraphs.forEach(para => {{
                const blockIdMatches = [...para.matchAll(blockIdPattern)];
                const blockIds = [...new Set(blockIdMatches.map(m => m[1]))];
                const paraMatches = [...para.matchAll(bodyPattern)];
                const paraBodyRefs = [...new Set(paraMatches.map(m => parseInt(m[1])))];
                const displayText = para.replace(/\\[block_id:[^\\]]+\\]/gi, '').trim();
                
                if (displayText) {{
                    html += `<p style="margin:0 0 12px 0; line-height:1.8;">${{escapeHtml(displayText)}}</p>`;
                }}
                
                if (blockIds.length > 0) {{
                    blockIds.forEach(blockId => {{
                        const displayName = blockId.replace('-', ' ').replace(/\\b\\w/g, l => l.toUpperCase());
                        html += `<button class="locate-btn" onclick="locateIssue('${{blockId}}')">📍 Locate ${{displayName}}</button> `;
                    }});
                }}
                
                if (paraBodyRefs.length > 0 && blockIds.length === 0) {{
                    paraBodyRefs.forEach(bodyNum => {{
                        html += `<button class="locate-btn" onclick="locateIssue('body-${{bodyNum}}')">📍 Locate Body ${{bodyNum}}</button> `;
                    }});
                }}
            }});
            
            html += '</div>';
            container.innerHTML = html;
        }}

        // Locate 功能：高亮对应模块（增强版，支持闪烁和诊断卡片联动）
        function locateIssue(blockId) {{
            if (!blockId) return;
            
            // 1. 在左侧原文区查找对应的模块
            const moduleEl = document.querySelector(`[data-block-id="${{blockId}}"]`);
            
            if (moduleEl) {{
                // 移除之前的高亮
                document.querySelectorAll('.essay-module').forEach(el => {{
                    el.classList.remove('highlight');
                    el.classList.remove('active-glow');
                    el.classList.remove('highlight-flash');
                }});
                
                // 滚动到目标元素
                moduleEl.scrollIntoView({{ behavior: 'smooth', block: 'center' }});
                
                // 添加闪烁高亮动画
                moduleEl.classList.add('highlight-flash');
                
                // 3 秒后移除高亮
                setTimeout(() => {{
                    moduleEl.classList.remove('highlight-flash');
                }}, 3000);
            }}
            
            // 2. 在 review-overlay 中查找对应的诊断卡片
            const reviewOverlay = document.getElementById('review-overlay');
            if (reviewOverlay && reviewOverlay.style.display !== 'none') {{
                // 查找包含该 blockId 的诊断卡片
                const diagnosticCards = document.querySelectorAll('.diagnostic-card');
                diagnosticCards.forEach(card => {{
                    card.classList.remove('active');
                }});
                
                // 尝试通过 block_id 匹配诊断卡片
                const blockIdPattern = new RegExp(blockId.replace('-', '\\\\s*-\\\\s*'), 'i');
                diagnosticCards.forEach(card => {{
                    const cardText = card.textContent || '';
                    if (blockIdPattern.test(cardText)) {{
                        card.classList.add('active');
                        card.scrollIntoView({{ behavior: 'smooth', block: 'nearest' }});
                    }}
                }});
            }}
            
            // 3. 在原文中标记对应的文本
            const originalTextEl = document.getElementById('review-original-text');
            if (originalTextEl) {{
                // 移除之前的 active 标记
                originalTextEl.querySelectorAll('mark').forEach(mark => {{
                    mark.classList.remove('active');
                }});
                
                // 查找包含 blockId 的 mark 元素
                const marks = originalTextEl.querySelectorAll('mark');
                marks.forEach(mark => {{
                    const dataIndex = mark.getAttribute('data-feedback-index');
                    if (dataIndex !== null) {{
                        // 这里可以根据需要进一步匹配
                        mark.classList.add('active');
                    }}
                }});
            }}
            
            // 向后兼容：如果找不到，尝试 locateBodyParagraph
            if (!moduleEl) {{
                const match = blockId.match(/body-(\\d+)/);
                if (match) {{
                    const bodyNum = parseInt(match[1], 10);
                    locateBodyParagraph(bodyNum);
                }}
            }}
        }}
        
        // 向后兼容：Locate Body 段落（保留旧函数）
        function locateBodyParagraph(bodyNum) {{
            locateIssue(`body-${{bodyNum}}`);
        }}

        // Re-submit 逻辑
        async function resubmitForReview() {{
            await submitReview(true);
        }}

        // --- 11. Mission Lab 抽屉 ---
        function showMissionLab() {{
            const drawer = document.getElementById('mission-lab-drawer');
            if (drawer) drawer.style.display = 'block';
        }}

        function closeMissionLab() {{
            const drawer = document.getElementById('mission-lab-drawer');
            if (drawer) drawer.style.display = 'none';
        }}

        // 点击抽屉外部关闭
        document.addEventListener('DOMContentLoaded', () => {{
            const drawer = document.getElementById('mission-lab-drawer');
            if (drawer) {{
                drawer.onclick = (e) => {{
                    if (e.target === drawer) closeMissionLab();
                }};
            }}
        }});
        
        // --- 12. 侧边栏折叠/展开控制 ---
        function toggleSidebar() {{
            const sidebar = document.getElementById('knowledge-sidebar');
            const toggle = document.getElementById('sidebar-toggle');
            const overlay = document.getElementById('sidebar-overlay');
            
            if (!sidebar || !toggle) return;
            
            const isExpanded = sidebar.classList.contains('expanded');
            
            if (isExpanded) {{
                closeSidebar();
            }} else {{
                sidebar.classList.add('expanded');
                toggle.classList.remove('collapsed');
                toggle.classList.add('expanded');
                overlay.classList.add('visible');
            }}
        }}
        
        function closeSidebar() {{
            const sidebar = document.getElementById('knowledge-sidebar');
            const toggle = document.getElementById('sidebar-toggle');
            const overlay = document.getElementById('sidebar-overlay');
            
            if (!sidebar || !toggle) return;
            
            sidebar.classList.remove('expanded');
            toggle.classList.remove('expanded');
            toggle.classList.add('collapsed');
            overlay.classList.remove('visible');
        }}
        
        // 检查 URL 参数，如果是 view-hub 模式，自动展开侧边栏
        window.addEventListener('load', () => {{
            const urlParams = new URLSearchParams(window.location.search);
            if (urlParams.get('view') === 'hub') {{
                setTimeout(() => {{
                    toggleSidebar();
                }}, 300);
            }}
        }});
        
        // --- 13. 计时器功能 ---
        let timerInterval = null;
        let timerSeconds = 0;
        let timerMode = 'up'; // 'up' or 'down'
        let timerCountdownMinutes = 45;
        let timerIsRunning = false;
        let timerStartTime = null;
        
        function toggleTimerPanel() {{
            const panel = document.getElementById('timer-panel');
            if (panel) {{
                panel.classList.toggle('visible');
            }}
        }}
        
        function setTimerMode(mode) {{
            timerMode = mode;
            const upBtn = document.getElementById('timer-mode-up');
            const downBtn = document.getElementById('timer-mode-down');
            const inputContainer = document.getElementById('timer-countdown-input-container');
            
            if (upBtn && downBtn) {{
                if (mode === 'up') {{
                    upBtn.classList.add('active');
                    downBtn.classList.remove('active');
                    if (inputContainer) inputContainer.style.display = 'none';
                }} else {{
                    upBtn.classList.remove('active');
                    downBtn.classList.add('active');
                    if (inputContainer) inputContainer.style.display = 'block';
                }}
            }}
            
            // 如果切换模式时计时器正在运行，需要重置
            if (timerIsRunning) {{
                resetTimer();
            }} else {{
                updateTimerDisplay();
            }}
        }}
        
        function startTimer() {{
            if (timerIsRunning) return;
            
            timerIsRunning = true;
            timerStartTime = Date.now();
            
            const startBtn = document.getElementById('timer-start-btn');
            const pauseBtn = document.getElementById('timer-pause-btn');
            
            if (startBtn) startBtn.style.display = 'none';
            if (pauseBtn) pauseBtn.style.display = 'block';
            
            // 如果是倒计时模式，读取设置的分钟数
            if (timerMode === 'down') {{
                const input = document.getElementById('timer-countdown-input');
                if (input) {{
                    const minutes = parseInt(input.value, 10);
                    if (minutes > 0 && minutes <= 180) {{
                        timerCountdownMinutes = minutes;
                        timerSeconds = minutes * 60;
                    }}
                }}
            }}
            
            timerInterval = setInterval(() => {{
                if (timerMode === 'up') {{
                    timerSeconds++;
                }} else {{
                    timerSeconds--;
                    if (timerSeconds <= 0) {{
                        timerSeconds = 0;
                        pauseTimer();
                        // 时间到，可以添加提示
                        showToast('⏰ Time is up! Please finish your conclusion.');
                    }}
                }}
                
                updateTimerDisplay();
            }}, 1000);
            
            updateTimerDisplay();
        }}
        
        function pauseTimer() {{
            if (!timerIsRunning) return;
            
            timerIsRunning = false;
            
            if (timerInterval) {{
                clearInterval(timerInterval);
                timerInterval = null;
            }}
            
            const startBtn = document.getElementById('timer-start-btn');
            const pauseBtn = document.getElementById('timer-pause-btn');
            
            if (startBtn) startBtn.style.display = 'block';
            if (pauseBtn) pauseBtn.style.display = 'none';
        }}
        
        function resetTimer() {{
            pauseTimer();
            
            if (timerMode === 'up') {{
                timerSeconds = 0;
            }} else {{
                const input = document.getElementById('timer-countdown-input');
                if (input) {{
                    const minutes = parseInt(input.value, 10);
                    if (minutes > 0 && minutes <= 180) {{
                        timerCountdownMinutes = minutes;
                        timerSeconds = minutes * 60;
                    }} else {{
                        timerSeconds = timerCountdownMinutes * 60;
                    }}
                }} else {{
                    timerSeconds = timerCountdownMinutes * 60;
                }}
            }}
            
            updateTimerDisplay();
        }}
        
        function updateTimerDisplay() {{
            const display = document.getElementById('timer-display');
            if (!display) return;
            
            let hours = Math.floor(timerSeconds / 3600);
            let minutes = Math.floor((timerSeconds % 3600) / 60);
            let seconds = timerSeconds % 60;
            
            const timeString = 
                String(hours).padStart(2, '0') + ':' +
                String(minutes).padStart(2, '0') + ':' +
                String(seconds).padStart(2, '0');
            
            display.textContent = timeString;
            
            // 倒计时模式：剩余 5 分钟时变红并闪烁
            if (timerMode === 'down' && timerSeconds > 0 && timerSeconds <= 300) {{
                display.classList.add('warning');
                if (timerSeconds === 300) {{
                    showToast('⚠️ 5 minutes remaining! Time to write your conclusion.');
                }}
            }} else {{
                display.classList.remove('warning');
            }}
        }}
        
        // 点击外部关闭计时器面板
        document.addEventListener('click', (e) => {{
            const panel = document.getElementById('timer-panel');
            const btn = document.querySelector('.timer-btn');
            if (panel && btn && !panel.contains(e.target) && !btn.contains(e.target)) {{
                panel.classList.remove('visible');
            }}
        }});
        
        // --- 14. 返回 Workspace ---
        function backToWorkspace() {{
            // 确保当前内容已保存
            saveToLocal();
            // 跳转回首页
            window.location.href = '../index.html';
        }}

        // 传统 SAVE / EXPORT 适配整篇 essay
        function save() {{
            saveToLocal();
            alert("Work Saved!");
        }}

        function exportDoc() {{
            const aiContent = document.getElementById('ai-content').innerText;
            const essayText = buildEssayText();
            const content = `WORK: ${{ID}}\\nQUESTION: ${{getCurrentQuestion()}}\\n\\n[ESSAY]\\n${{essayText}}\\n\\n[AI FEEDBACK]\\n${{aiContent}}`;
            const blob = new Blob([content], {{ type: 'text/plain' }});
            const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = `Submission_${{ID}}.txt`; a.click();

            const preview = document.getElementById('export-preview');
            const container = document.getElementById('export-essay');
            if (preview && container) {{
                container.innerHTML = buildEssayHtml();
                preview.style.display = 'block';
                preview.scrollIntoView({{ behavior: 'smooth' }});
            }}
        }}

        // --- 9. Toast 提示函数 ---
        function showToast(message) {{
            const container = document.getElementById('toast-container');
            if (!container) return;
            
            const toast = document.createElement('div');
            toast.className = 'toast';
            toast.innerHTML = `<span class="toast-icon">✅</span><span>${{message}}</span>`;
            
            container.innerHTML = '';
            container.appendChild(toast);
            
            // 3 秒后自动移除
            setTimeout(() => {{
                if (toast.parentNode) {{
                    toast.parentNode.removeChild(toast);
                }}
            }}, 3000);
        }}

        // --- 10. 自动拆解投喂逻辑 ---
        function processQuickAuditData() {{
            // 检查是否有 Quick Audit 的待处理数据
            const pendingIntro = localStorage.getItem('pendingIntro');
            const pendingConclusion = localStorage.getItem('pendingConclusion');
            const pendingBodiesRaw = localStorage.getItem('pendingBodies');
            
            if (!pendingIntro && !pendingConclusion && !pendingBodiesRaw) {{
                return false; // 没有待处理数据
            }}
            
            // 清空现有模块（确保清除所有输入框）
            modules = [];
            
            let moduleCount = 0;
            
            // 创建 Intro 模块（如果有）
            if (pendingIntro) {{
                const introMod = createEmptyModule('intro');
                introMod.mode = 'free';
                introMod.freeText = pendingIntro;
                modules.push(introMod);
                moduleCount++;
            }}
            
            // 创建 Body 模块（根据 pendingBodies 的长度自动生成）
            if (pendingBodiesRaw) {{
                try {{
                    const bodies = JSON.parse(pendingBodiesRaw);
                    if (Array.isArray(bodies) && bodies.length > 0) {{
                        bodies.forEach(bodyText => {{
                            if (bodyText && bodyText.trim()) {{
                                const bodyMod = createEmptyModule('body');
                                bodyMod.mode = 'free';
                                bodyMod.freeText = bodyText.trim();
                                modules.push(bodyMod);
                                moduleCount++;
                            }}
                        }});
                    }}
                }} catch (e) {{
                    console.error('Failed to parse pendingBodies:', e);
                }}
            }}
            
            // 创建 Conclusion 模块（如果有）
            if (pendingConclusion) {{
                const conclMod = createEmptyModule('conclusion');
                conclMod.mode = 'free';
                conclMod.freeText = pendingConclusion;
                modules.push(conclMod);
                moduleCount++;
            }}
            
            // 清除 localStorage 中的待处理数据（防止下次打开页面误触发）
            localStorage.removeItem('pendingIntro');
            localStorage.removeItem('pendingConclusion');
            localStorage.removeItem('pendingBodies');
            
            // 保存到当前任务的状态
            saveToLocal();
            
            // 渲染模块
            renderModules();
            
            // 显示 Toast 反馈提示
            showToast("Audit Complete: We've split your text into PEEL blocks. Review the logic below!");
            
            // Audit Mode：自动提交批改
            if (workspaceMode === 'audit') {{
                setTimeout(() => {{
                    showPreviewView();
                    setTimeout(() => {{
                        confirmSubmitFromPreview();
                    }}, 500);
                }}, 1000);
            }}
            
            return true; // 成功处理
        }}

        // 初始恢复 + 默认 body 模块 + Quick Audit 数据导入
        window.addEventListener('load', () => {{
            // 首先检测模式
            detectWorkspaceMode();
            
            // 优先处理 Quick Audit 数据
            const hasQuickAuditData = processQuickAuditData();
            
            if (!hasQuickAuditData) {{
                // 如果没有 Quick Audit 数据，正常加载本地保存的状态
                loadFromLocal();
            }}
            
            // 如果没有模块，创建默认 body 模块（仅在 Practice Mode）
            if (!modules.length && workspaceMode === 'practice') {{
                modules.push(createEmptyModule('body'));
            }}
            
            renderModules();
            updateGlobalWordCount();
            
            // [Agent-02 守门员] 初始化提交按钮状态
            validateSubmission();
            
            // 监听所有 textarea 的输入，实时更新全局字数
            document.addEventListener('input', (e) => {{
                if (e.target.tagName === 'TEXTAREA' && e.target.hasAttribute('data-module')) {{
                    updateGlobalWordCount();
                }}
            }});
            }});
        </script>
        
        <!-- 引入 visual_audit_v3.js - 必须在主逻辑脚本之后，确保 DOM 已加载 -->
        <script src="/visual_audit_v3.js"></script>
    </body>
</html>"""


def create_page(mid, question):
    html = HTML_TEMPLATE.format(mid=mid, question=question)
    with open(f"assets/missions/{mid}_workspace.html", "w", encoding="utf-8") as f:
        f.write(html)

missions = [
    ("CR_M1", "Assess the reasons for the opposition to the Civil Rights movement in the Southern states in the 1950s."),
    ("CR_M2", "Evaluate how successful the Civil Rights movement was in the 1950s."),
    ("CR_M3", "Assess the impact of federal institutions on civil rights in the late 1940s and 1950s."),
    ("CR_M4", "Analyse the effectiveness of the NAACP in promoting civil rights in the late 1940s and 1950s."),
    ("CR_M5", "'Progress towards greater civil rights in the 1950s was mainly brought about by federal institutions.' Evaluate this view.")
]

for m_id, q in missions:
    create_page(m_id, q)
    print(f">>> Updated: {m_id}")